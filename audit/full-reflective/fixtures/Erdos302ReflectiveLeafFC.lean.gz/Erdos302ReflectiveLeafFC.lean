import Erdos302SparseCertificateFC

/-!
# Kernel-evaluated dual leaves

A dual leaf is checked by a Boolean function on list data, which the kernel
evaluates directly (`decide +kernel`).  This replaces the per-vertex load
equations of the generated leaf modules.  `assigned_of_leafCheck` turns an
accepted check into the same `AssignedCoverLowerBound` that `assigned_dual`
produces, so the existing branch composition is unchanged.

Rows are `WRow` records.  A row whose vertices form a reciprocal triple is
accepted by `tripleOK` without any lemma; every other row needs a
`CoverLowerBound` lemma in `RowsValid`.

For a cover `S`, write `L v` for the weighted row load of `v` and `C` for the
charged vertices (`ones`, and free vertices with `L v > D`).  The check
`(r - 1) D + Σ_C L < Σ_j w_j d_j + |C| D` implies `r ≤ |S|`, because
`Σ_j w_j d_j ≤ Σ_S L` and `Σ_S L + |C| D ≤ |S| D + Σ_C L` vertex by vertex.
-/

namespace Erdos302Reflective

open Finset Erdos302CoverRowsFC

noncomputable section

/-! The functions evaluated by the kernel are written with `List.rec` directly.
Structural recursion would compile through `brecOn`; on cert53 leaf 8 that
roughly doubled the kernel's time and memory (7.4 s / 1.3 GB against
4.3 s / 0.7 GB).  Each gets `rfl` equations for the proofs. -/

/-- Membership test reducing through the kernel's `Nat.beq`. -/
def memNat (v : ℕ) (l : List ℕ) : Bool :=
  List.rec false (fun x _ ih => cond (Nat.beq v x) true ih) l

theorem memNat_nil (v : ℕ) : memNat v [] = false := rfl

theorem memNat_cons (v x : ℕ) (xs : List ℕ) :
    memNat v (x :: xs) = cond (Nat.beq v x) true (memNat v xs) := rfl

theorem memNat_iff (v : ℕ) : ∀ l : List ℕ, memNat v l = true ↔ v ∈ l
  | [] => by simp [memNat_nil]
  | x :: xs => by
    rw [List.mem_cons, ← memNat_iff v xs]
    cases hbx : Nat.beq v x
    · have h : v ≠ x := Nat.ne_of_beq_eq_false hbx
      simp [memNat_cons, hbx, h]
    · have h : v = x := Nat.eq_of_beq_eq_true hbx
      simp [memNat_cons, hbx, h]

theorem memNat_false {v : ℕ} {l : List ℕ} (h : v ∉ l) : memNat v l = false := by
  cases hm : memNat v l
  · rfl
  · exact absurd ((memNat_iff v l).mp hm) h

structure WRow where
  verts : List ℕ
  demand : ℕ
  weight : ℕ

/-- Weighted load of `v`: the sum of the weights of the rows containing `v`. -/
def loadAt (v : ℕ) (rows : List WRow) : ℕ :=
  List.rec 0 (fun r _ ih => cond (memNat v r.verts) r.weight 0 + ih) rows

theorem loadAt_nil (v : ℕ) : loadAt v [] = 0 := rfl

theorem loadAt_cons (v : ℕ) (r : WRow) (rs : List WRow) :
    loadAt v (r :: rs) = cond (memNat v r.verts) r.weight 0 + loadAt v rs := rfl

def rowSum (rows : List WRow) : ℕ :=
  List.rec 0 (fun r _ ih => r.weight * r.demand + ih) rows

theorem rowSum_nil : rowSum [] = 0 := rfl

theorem rowSum_cons (r : WRow) (rs : List WRow) :
    rowSum (r :: rs) = r.weight * r.demand + rowSum rs := rfl

/-- Vertices whose correction term is charged: all of `ones`, and free vertices
whose load exceeds `D`. -/
def charged (ones zeros : List ℕ) (rows : List WRow) (D v : ℕ) : Bool :=
  cond (memNat v ones) true (cond (memNat v zeros) false (Nat.blt D (loadAt v rows)))

/-- `(p + |C| D, n + Σ_C L)` over the listed vertices. -/
def charge (ones zeros : List ℕ) (rows : List WRow) (D : ℕ) (U : List ℕ) : ℕ → ℕ → ℕ × ℕ :=
  List.rec (fun p n => (p, n))
    (fun v _ ih p n =>
      cond (charged ones zeros rows D v) (ih (p + D) (n + loadAt v rows)) (ih p n)) U

theorem charge_nil (ones zeros : List ℕ) (rows : List WRow) (D p n : ℕ) :
    charge ones zeros rows D [] p n = (p, n) := rfl

theorem charge_cons (ones zeros : List ℕ) (rows : List WRow) (D v : ℕ) (vs : List ℕ) (p n : ℕ) :
    charge ones zeros rows D (v :: vs) p n =
      cond (charged ones zeros rows D v)
        (charge ones zeros rows D vs (p + D) (n + loadAt v rows))
        (charge ones zeros rows D vs p n) := rfl

def allIn (U l : List ℕ) : Bool :=
  List.rec true (fun v _ ih => cond (memNat v U) ih false) l

theorem allIn_cons (U : List ℕ) (v : ℕ) (vs : List ℕ) :
    allIn U (v :: vs) = cond (memNat v U) (allIn U vs) false := rfl

def rowsIn (U : List ℕ) (rows : List WRow) : Bool :=
  List.rec true (fun r _ ih => cond (allIn U r.verts) ih false) rows

theorem rowsIn_cons (U : List ℕ) (r : WRow) (rs : List WRow) :
    rowsIn U (r :: rs) = cond (allIn U r.verts) (rowsIn U rs) false := rfl

def strictSorted : List ℕ → Bool
  | [] => true
  | [_] => true
  | a :: b :: rest => cond (Nat.blt a b) (strictSorted (b :: rest)) false

def leafCheck (U ones zeros : List ℕ) (rows : List WRow) (D r : ℕ) : Bool :=
  cond (rowsIn U rows)
    (match charge ones zeros rows D U 0 0 with
      | (p, n) => Nat.blt ((r - 1) * D + n) (rowSum rows + p))
    false

/-- A sorted reciprocal triple `a < b < c` with `a (b + c) = b c` and demand 1. -/
def tripleOK (r : WRow) : Bool :=
  match r.verts with
  | [a, b, c] =>
    cond (Nat.beq r.demand 1)
      (cond (Nat.blt 0 a) (cond (Nat.blt a b)
        (cond (Nat.blt b c) (Nat.beq (a * (b + c)) (b * c)) false) false) false) false
  | _ => false

/-- Each row is a checked reciprocal triple or comes with its lower-bound lemma. -/
inductive RowsValid : List WRow → Prop
  | nil : RowsValid []
  | triple {r : WRow} {rs : List WRow} : tripleOK r = true → RowsValid rs → RowsValid (r :: rs)
  | given {r : WRow} {rs : List WRow} :
      CoverLowerBound r.verts.toFinset r.demand → RowsValid rs → RowsValid (r :: rs)

theorem tripleOK_sound {r : WRow} (h : tripleOK r = true) :
    CoverLowerBound r.verts.toFinset r.demand := by
  obtain ⟨verts, demand, weight⟩ := r
  match verts, h with
  | [a, b, c], h =>
    simp only [tripleOK] at h
    cases hd : Nat.beq demand 1 <;> simp only [hd, cond_false, cond_true] at h
    · exact absurd h (by decide)
    cases ha : Nat.blt 0 a <;> simp only [ha, cond_false, cond_true] at h
    · exact absurd h (by decide)
    cases hab : Nat.blt a b <;> simp only [hab, cond_false, cond_true] at h
    · exact absurd h (by decide)
    cases hbc : Nat.blt b c <;> simp only [hbc, cond_false, cond_true] at h
    · exact absurd h (by decide)
    have hd' : demand = 1 := Nat.eq_of_beq_eq_true hd
    have ha' : 0 < a := by simpa using ha
    have hab' : a < b := by simpa using hab
    have hbc' : b < c := by simpa using hbc
    have heq : a * (b + c) = b * c := Nat.eq_of_beq_eq_true h
    subst hd'
    have hq : (1 : ℚ) / a = (1 : ℚ) / b + (1 : ℚ) / c := by
      have ha0 : (a : ℚ) ≠ 0 := by exact_mod_cast ha'.ne'
      have hb0 : (b : ℚ) ≠ 0 := by exact_mod_cast (ha'.trans hab').ne'
      have hc0 : (c : ℚ) ≠ 0 := by exact_mod_cast (ha'.trans (hab'.trans hbc')).ne'
      have hq' : (a : ℚ) * (b + c) = b * c := by exact_mod_cast heq
      field_simp
      linarith
    have hset : ([a, b, c] : List ℕ).toFinset = ({a, b, c} : Finset ℕ) := by
      ext x
      simp
    show CoverLowerBound ([a, b, c] : List ℕ).toFinset 1
    rw [hset]
    exact triple_row_lower_bound hab'.ne (hab'.trans hbc').ne hbc'.ne hq

theorem RowsValid.bound {rows : List WRow} (h : RowsValid rows) :
    ∀ r ∈ rows, CoverLowerBound r.verts.toFinset r.demand := by
  induction h with
  | nil => intro r hr; exact absurd hr (by simp)
  | triple ht _ ih =>
    intro r hr
    rcases List.mem_cons.mp hr with rfl | hr
    · exact tripleOK_sound ht
    · exact ih r hr
  | given hl _ ih =>
    intro r hr
    rcases List.mem_cons.mp hr with rfl | hr
    · exact hl
    · exact ih r hr

theorem allIn_sound {U : List ℕ} : ∀ l : List ℕ, allIn U l = true → ∀ v ∈ l, v ∈ U
  | [], _, v, hv => absurd hv (by simp)
  | x :: xs, h, v, hv => by
    simp only [allIn_cons] at h
    cases hx : memNat x U <;> simp only [hx, cond_false, cond_true] at h
    · exact absurd h (by decide)
    rcases List.mem_cons.mp hv with rfl | hv
    · exact (memNat_iff _ U).mp hx
    · exact allIn_sound xs h v hv

theorem rowsIn_sound {U : List ℕ} : ∀ rows : List WRow, rowsIn U rows = true →
    ∀ r ∈ rows, r.verts.toFinset ⊆ U.toFinset
  | [], _, r, hr => absurd hr (by simp)
  | x :: xs, h, r, hr => by
    simp only [rowsIn_cons] at h
    cases hx : allIn U x.verts <;> simp only [hx, cond_false, cond_true] at h
    · exact absurd h (by decide)
    rcases List.mem_cons.mp hr with rfl | hr
    · intro v hv
      exact List.mem_toFinset.mpr (allIn_sound _ hx v (List.mem_toFinset.mp hv))
    · exact rowsIn_sound xs h r hr

theorem strictSorted_cons {a : ℕ} : ∀ {l : List ℕ}, strictSorted (a :: l) = true →
    strictSorted l = true ∧ ∀ x ∈ l, a < x
  | [], _ => by simp [strictSorted]
  | b :: rest, h => by
    simp only [strictSorted] at h
    cases hab : Nat.blt a b <;> simp only [hab, cond_false, cond_true] at h
    · exact absurd h (by decide)
    have hab' : a < b := by simpa using hab
    refine ⟨h, fun x hx => ?_⟩
    rcases List.mem_cons.mp hx with rfl | hx
    · exact hab'
    · exact hab'.trans ((strictSorted_cons h).2 x hx)

theorem nodup_of_strictSorted : ∀ {l : List ℕ}, strictSorted l = true → l.Nodup
  | [], _ => List.nodup_nil
  | a :: l, h => by
    obtain ⟨hl, hlt⟩ := strictSorted_cons h
    exact List.nodup_cons.mpr ⟨fun ha => lt_irrefl a (hlt a ha), nodup_of_strictSorted hl⟩

theorem charge_eq (ones zeros : List ℕ) (rows : List WRow) (D : ℕ) :
    ∀ (U : List ℕ), U.Nodup → ∀ p n : ℕ,
      charge ones zeros rows D U p n =
        (p + ∑ v ∈ U.toFinset.filter (fun v => charged ones zeros rows D v = true), D,
         n + ∑ v ∈ U.toFinset.filter (fun v => charged ones zeros rows D v = true), loadAt v rows)
  | [], _, p, n => by simp [charge_nil]
  | v :: vs, hnd, p, n => by
    have hv : v ∉ vs := (List.nodup_cons.mp hnd).1
    have hvs : vs.Nodup := (List.nodup_cons.mp hnd).2
    have hvf : v ∉ vs.toFinset.filter (fun v => charged ones zeros rows D v = true) := by
      simp [hv]
    rw [List.toFinset_cons, Finset.filter_insert]
    cases hc : charged ones zeros rows D v
    · simp only [charge_cons, hc, cond_false, charge_eq ones zeros rows D vs hvs p n]
      simp
    · simp only [charge_cons, hc, cond_true, charge_eq ones zeros rows D vs hvs (p + D)
        (n + loadAt v rows), if_true, Finset.sum_insert hvf]
      ext <;> simp only [] <;> omega

theorem rowSum_le {S : Finset ℕ} : ∀ rows : List WRow,
    (∀ r ∈ rows, r.demand ≤ (S ∩ r.verts.toFinset).card) →
      rowSum rows ≤ ∑ v ∈ S, loadAt v rows
  | [], _ => by simp [rowSum_nil]
  | r :: rs, h => by
    have ih := rowSum_le rs (fun x hx => h x (List.mem_cons_of_mem _ hx))
    have hr := h r (by simp)
    have hterm : ∀ v, cond (memNat v r.verts) r.weight 0 =
        if v ∈ r.verts.toFinset then r.weight else 0 := by
      intro v
      by_cases hv : v ∈ r.verts
      · simp [(memNat_iff v r.verts).mpr hv, hv]
      · simp [memNat_false hv, hv]
    have hcount : ∑ v ∈ S, cond (memNat v r.verts) r.weight 0 =
        r.weight * (S ∩ r.verts.toFinset).card := by
      simp only [hterm]
      rw [← Finset.sum_filter, Finset.sum_const_nat (fun _ _ => rfl),
        Finset.filter_mem_eq_inter, Nat.mul_comm]
    have hmul := Nat.mul_le_mul_left r.weight hr
    simp only [rowSum_cons, loadAt_cons, Finset.sum_add_distrib, hcount]
    omega

theorem assigned_of_leafCheck {U ones zeros : Finset ℕ} (UL onesL zerosL : List ℕ)
    (rows : List WRow) (D r : ℕ)
    (hU : U = UL.toFinset) (hones : ones = onesL.toFinset) (hzeros : zeros = zerosL.toFinset)
    (hsorted : strictSorted UL = true) (hrows : RowsValid rows)
    (hcheck : leafCheck UL onesL zerosL rows D r = true) :
    AssignedCoverLowerBound U ones zeros r := by
  subst hU hones hzeros
  intro S hcover hSU hS1 hS0
  simp only [leafCheck] at hcheck
  cases hin : rowsIn UL rows <;> simp only [hin, cond_false, cond_true] at hcheck
  · exact absurd hcheck (by decide)
  rw [charge_eq onesL zerosL rows D UL (nodup_of_strictSorted hsorted)] at hcheck
  simp only [Nat.zero_add, Nat.blt_eq] at hcheck
  set C := UL.toFinset.filter (fun v => charged onesL zerosL rows D v = true) with hC
  -- Row lemmas give each demand inside the cover.
  have hdem : ∀ x ∈ rows, x.demand ≤ (S ∩ x.verts.toFinset).card := by
    intro x hx
    exact hrows.bound x hx (S ∩ x.verts.toFinset)
      (restrict_cover (rowsIn_sound rows hin x hx) hcover)
  have hrowsum := rowSum_le rows hdem
  -- Vertex-by-vertex comparison outside `S ∩ C`.
  have hSC : ∑ v ∈ S \ C, loadAt v rows ≤ ∑ v ∈ S \ C, D := by
    apply Finset.sum_le_sum
    intro v hv
    obtain ⟨hvS, hvC⟩ := Finset.mem_sdiff.mp hv
    have hvU : v ∈ UL.toFinset := hSU hvS
    have hch : charged onesL zerosL rows D v = false := by
      cases hc : charged onesL zerosL rows D v
      · rfl
      · exact absurd (Finset.mem_filter.mpr ⟨hvU, hc⟩) hvC
    have hz : memNat v zerosL = false := by
      apply memNat_false
      intro hz
      exact Finset.disjoint_left.mp hS0 hvS (List.mem_toFinset.mpr hz)
    simp only [charged, hz, cond_false] at hch
    cases ho : memNat v onesL <;> simp only [ho, cond_false, cond_true] at hch
    · by_contra hlt
      have hb : Nat.blt D (loadAt v rows) = true := by
        rw [Nat.blt_eq]
        omega
      rw [hb] at hch
      exact absurd hch (by decide)
    · exact absurd hch (by decide)
  have hCS : ∑ v ∈ C \ S, D ≤ ∑ v ∈ C \ S, loadAt v rows := by
    apply Finset.sum_le_sum
    intro v hv
    obtain ⟨hvC, hvS⟩ := Finset.mem_sdiff.mp hv
    have hc : charged onesL zerosL rows D v = true := (Finset.mem_filter.mp hvC).2
    have ho : memNat v onesL = false := by
      apply memNat_false
      intro ho
      exact hvS (hS1 (List.mem_toFinset.mpr ho))
    simp only [charged, ho, cond_false] at hc
    cases hz : memNat v zerosL <;> simp only [hz, cond_false, cond_true] at hc
    · have : D < loadAt v rows := by simpa using hc
      omega
    · exact absurd hc (by decide)
  have h1 := Finset.sum_inter_add_sum_diff S C (fun v => loadAt v rows)
  have h2 := Finset.sum_inter_add_sum_diff C S (fun v => loadAt v rows)
  have h3 := Finset.sum_inter_add_sum_diff S C (fun _ => D)
  have h4 := Finset.sum_inter_add_sum_diff C S (fun _ => D)
  rw [Finset.inter_comm C S] at h2 h4
  have hSD : ∑ _v ∈ S, D = S.card * D := Finset.sum_const_nat (fun _ _ => rfl)
  have hmain : (r - 1) * D < S.card * D := by omega
  have := Nat.lt_of_mul_lt_mul_right hmain
  omega

/-- The leaf statement with list-valued support and assignments. -/
theorem assigned_of_leafCheck_list (UL onesL zerosL : List ℕ) (rows : List WRow) (D r : ℕ)
    (hsorted : strictSorted UL = true) (hrows : RowsValid rows)
    (hcheck : leafCheck UL onesL zerosL rows D r = true) :
    AssignedCoverLowerBound UL.toFinset onesL.toFinset zerosL.toFinset r :=
  assigned_of_leafCheck UL onesL zerosL rows D r rfl rfl rfl hsorted hrows hcheck

theorem assigned_split_list {U : Finset ℕ} {ones zeros : List ℕ} {r : ℕ} (v : ℕ)
    (yes : AssignedCoverLowerBound U (v :: ones).toFinset zeros.toFinset r)
    (no : AssignedCoverLowerBound U ones.toFinset (v :: zeros).toFinset r) :
    AssignedCoverLowerBound U ones.toFinset zeros.toFinset r := by
  rw [List.toFinset_cons] at yes no
  exact assigned_split v yes no

theorem cover_of_assigned_list {U : Finset ℕ} {r : ℕ}
    (h : AssignedCoverLowerBound U ([] : List ℕ).toFinset ([] : List ℕ).toFinset r) :
    CoverLowerBound U r := by
  rw [List.toFinset_nil] at h
  exact cover_of_assigned h

/-! Rows citing an earlier lemma at a multiple `m • L` are written `scaleList m L`,
so the cited theorem transfers by `scaled_cover` without a literal copy. -/

def scaleList (m : ℕ) (L : List ℕ) : List ℕ :=
  List.rec [] (fun x _ ih => m * x :: ih) L

theorem scaleList_eq_map (m : ℕ) : ∀ L : List ℕ, scaleList m L = L.map (fun x => m * x)
  | [] => rfl
  | x :: xs => by
    show m * x :: scaleList m xs = _
    rw [scaleList_eq_map m xs, List.map_cons]

def allPos (L : List ℕ) : Bool :=
  List.rec true (fun x _ ih => cond (Nat.blt 0 x) ih false) L

theorem allPos_sound : ∀ L : List ℕ, allPos L = true → ∀ u ∈ L, 0 < u
  | [], _, u, hu => absurd hu (by simp)
  | x :: xs, h, u, hu => by
    have h' : cond (Nat.blt 0 x) (allPos xs) false = true := h
    cases hx : Nat.blt 0 x <;> simp only [hx, cond_false, cond_true] at h'
    · exact absurd h' (by decide)
    rcases List.mem_cons.mp hu with rfl | hu
    · simpa using hx
    · exact allPos_sound xs h' u hu

theorem scaled_cover {m r : ℕ} {L : List ℕ} (hm : 0 < m) (hpos : allPos L = true)
    (h : CoverLowerBound L.toFinset r) : CoverLowerBound (scaleList m L).toFinset r := by
  have hset : (scaleList m L).toFinset = scaleSet m L.toFinset := by
    rw [scaleList_eq_map]
    ext x
    simp [scaleSet]
  rw [hset]
  exact scaled_cover_lower_bound h hm
    (fun u hu => allPos_sound L hpos u (List.mem_toFinset.mp hu))

end

end Erdos302Reflective

#print axioms Erdos302Reflective.assigned_of_leafCheck
#print axioms Erdos302Reflective.assigned_split_list
#print axioms Erdos302Reflective.cover_of_assigned_list
#print axioms Erdos302Reflective.scaled_cover
