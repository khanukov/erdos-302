#!/usr/bin/env python3
"""Export verified local weighted-cover instances for independent solvers.
OPB files are problem instances, NOT VeriPB proof logs or Lean certificates.
"""
from pathlib import Path
import argparse,importlib.util,json
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('boundary',ROOT/'verify_boundary.py')
V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--out',type=Path,default=ROOT/'opb');args=ap.parse_args()
    cert=V.read_json(ROOT/'certificate.json');r=V.validate(cert);args.out.mkdir(exist_ok=True,parents=True)
    tables={t['id']:t for t in cert['tables']};defs={i['id']:i for i in cert['inequalities']};manifest=[]
    for s in cert['strict_relaxation_examples']:
        row=next(i for i in r['proved_rows']if i['id']==s['inequality']);t=tables[defs[row['id']]['table']];S=t['support'];ix={v:i+1 for i,v in enumerate(S)};coef=dict(row['coefficients'])
        lines=[f'* #variable= {len(S)} #constraint= {len(t["edges"])}',
               '* x_i=1 means the corresponding denominator is omitted.',
               '* Proven weighted optimum: '+str(row['rhs']),
               'min: '+' '.join(f'+{coef.get(v,0)} x{ix[v]}'for v in S if coef.get(v,0))+' ;']
        lines+=[' '.join(f'+1 x{ix[v]}'for v in e)+' >= 1 ;'for e in t['edges']]
        file=args.out/(row['id']+'.opb');file.write_text('\n'.join(lines)+'\n')
        covers=V.semantic_covers(S,t['edges']);best=min(covers,key=lambda mask:sum(coef.get(v,0)for i,v in enumerate(S)if(mask>>i)&1));value=sum(coef.get(v,0)for i,v in enumerate(S)if(best>>i)&1)
        V.require(value==row['rhs'],'Claimed weighted optimum is not attained')
        manifest.append({'file':file.name,'variables':S,'optimum':value,'cover_witness':[v for i,v in enumerate(S)if(best>>i)&1]})
    (args.out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('EXPORTED_'+str(len(manifest))+'_EXACT_LOCAL_OPTIMIZATION_INSTANCES')
if __name__=='__main__':main()
