#!/usr/bin/env python3
"""Deterministically emit small finite Lean obligations, not a global theorem.
The output is an UNCOMPILED integration source in this artifact.
"""
from pathlib import Path
import argparse
import importlib.util

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('checked_boundary',ROOT/'verify_boundary.py')
V=importlib.util.module_from_spec(spec);spec.loader.exec_module(V)

def bits_sum(indices,coefficients=None):
    if coefficients is None:coefficients=[1]*len(indices)
    terms=[]
    for i,c in zip(indices,coefficients):
        if c==0:continue
        if c==1:terms.append(f'bit x{i}')
        else:terms.append(f'({c} : Int) * (bit x{i} : Int)')
    return ' + '.join(terms) or '0'

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--check',action='store_true');args=ap.parse_args()
    cert=V.read_json(ROOT/'certificate.json');report=V.validate(cert)
    gates={g['id']:g['vertices']for g in cert['gates']}
    lines=['import Mathlib','','/-! Generated from certificate.json.','Finite obligations only. This source has NOT been compiled in this artifact.','No theorem about limsup or f302 is claimed here. -/','','set_option maxRecDepth 100000','set_option maxHeartbeats 4000000','','namespace Erdos302BoundaryV1','',
           'def bit (b : Bool) : Nat := if b then 1 else 0','']
    names=[]
    def emit(name,S,E,antecedent,goal):
        params=' '.join(f'x{i}'for i in range(len(S)))
        index={v:i for i,v in enumerate(S)}
        clauses=['(1 ≤ '+ ' + '.join(f'bit x{index[v]}'for v in e)+')'for e in E]
        h=' ∧ '.join(clauses)or'True'
        typ=f'({h}) → '+(f'({antecedent}) → 'if antecedent else'')+goal
        lines.extend([f'theorem {name} :',f'    ∀ {params} : Bool,',f'    {typ} := by','  decide +kernel',''])
        names.append(name)
    for t in cert['tables']:
        S=t['support'];B=t['boundary'];I=[v for v in S if v not in B];index={v:i for i,v in enumerate(S)}
        arithmetic=[]
        for a,b,c in t['edges']:arithmetic.append(f'({a} < {b} ∧ {b} < {c} ∧ {b} * {c} = {a} * ({b} + {c}))')
        name='edges_'+t['id'];lines.extend([f'theorem {name} :','    '+' ∧ '.join(arithmetic)+' := by','  decide +kernel','']);names.append(name)
        for state,c in enumerate(t['cells']):
            a=' ∧ '.join(f'x{index[v]} = '+('true'if(state>>j)&1 else'false')for j,v in enumerate(B))
            goal='False'if c['lower']is None else f"{c['lower']} ≤ "+' + '.join(f'bit x{index[v]}'for v in I)
            emit(f'cell_{t["id"]}_{state}',S,t['edges'],a,goal)
    for r in report['proved_rows']:
        S=sorted(set(v for v,c in r['coefficients'])|{v for g,c in r['gate_terms']for v in gates[g]})
        index={v:i for i,v in enumerate(S)};terms=[]
        for v,c in r['coefficients']:terms.append(f'({c} : Int) * (bit x{index[v]} : Int)')
        for g,c in r['gate_terms']:
            prod=' * '.join(f'(bit x{index[v]} : Int)'for v in gates[g]);terms.append(f'({c} : Int) * ({prod})')
        goal=f'({r["rhs"]} : Int) ≤ '+' + '.join(terms)
        emit('inequality_'+r['id'],S,V.reciprocal_edges(S),'',goal)
    for name in names:lines.append('#print axioms '+name)
    lines.extend(['','end Erdos302BoundaryV1',''])
    output='\n'.join(lines);dest=ROOT/'lean/BoundaryCertificates.lean'
    if args.check:
        V.require(dest.read_text()==output,'Lean source is not the deterministic current generation')
    else:dest.write_text(output)
    print(f'GENERATED_{len(names)}_FINITE_DECLARATIONS; compilation has not been performed')
if __name__=='__main__':main()
