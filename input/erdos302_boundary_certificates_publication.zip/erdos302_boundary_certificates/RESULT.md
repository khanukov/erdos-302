# Results of this artifact

**No new global coefficient is claimed.** The source compact endpoint is retained:

\[
\limsup f_{302}(N)/N\le 0.841230807050.
\]

The integrated exact replay gives

```text
0.84123080704999166799374219018487743560979505884535667546480113624
```

with finite error `55064831540`. All twenty full-profile SHA-256 values are
unchanged after adding the eleven proved cardinal consequences.

## New local certificate content

| Item | Verified count |
|---|---:|
| Exact boundary tables | 12 |
| Boundary states, including proved impossible states | 84 |
| Assignments in exhaustive table verification | 4,928 |
| Weighted/conditional inequality declarations | 12 |
| Further exact sum/rounding deductions | 11 |
| Local strict separations from all subset-cardinality constraints | 9 |
| Subset-cardinality constraints checked on separating points | 4,352 |
| Redundant direct cover checks of all emitted inequalities | 5,272 |
| Invalid variants rejected | 30 |
| Finite arithmetic tests of the parametric family | 197 |
| Generated finite Lean declarations | 119, **not compiled** |

The certificate has nonnegative interior charges, signed boundary and defined
AND-gate coefficients, complete state coverage, exact witnesses, and explicit
coefficient cancellation. Gates are definitions, not free assumptions. There is
no new-constant declaration based solely on local improvements.

Both normal and optimized Python runs produced byte-identical mathematical
reports; the independent enumeration and mutation tests passed in both modes.
Full compact replay in the recorded run took 20.55 seconds and about 212 MiB
maximum resident memory. These are measurements in this environment, not Lean
benchmarks or forecasts for another machine.

The strongest verified *new* statement here is the local polyhedral separation,
not a numerical theorem replacing the inherited endpoint. The generic method is
not claimed as a historical invention. Human review and a compiled Lean bridge
remain outstanding.
