#!/usr/bin/env python3
"""Replay the pinned compact bound and the boundary extension from local files.
Does not rebuild external Lean sources or compile the new Lean source.
"""
from pathlib import Path
import argparse,importlib.util,json,hashlib,subprocess,sys
ROOT=Path(__file__).resolve().parent

def need(ok,msg):
    if not ok:raise RuntimeError(msg)

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def baseline_hashes():
    base=(ROOT/'baseline').resolve();count=0
    for line in (base/'SHA256SUMS').read_text().splitlines():
        if not line.strip():continue
        sha,name=line.split(None,1);name=name.strip().lstrip('*');p=(base/name).resolve()
        need(p.is_relative_to(base)and p.is_file(),'Invalid baseline manifest path')
        need(hashlib.sha256(p.read_bytes()).hexdigest()==sha,'Baseline file mismatch: '+name);count+=1
    return count

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--report',type=Path);args=ap.parse_args()
    hashed=baseline_hashes();V=load('pinned_compact',ROOT/'baseline/verify.py');B=load('boundary_extension',ROOT/'verify_boundary.py')
    levels=V.upstream();vals,roots,finite=V.check_bank(V.read(ROOT/'baseline/bank.json.xz'),levels)
    extensions,extstats=V.check_extensions(V.read(ROOT/'baseline/extensions.json'),vals)
    local=B.validate(B.read_json(ROOT/'certificate.json'))
    new_cardinality=[]
    for row in local['proved_rows']:
        if not row['gate_terms'] and all(w==1 for v,w in row['coefficients']):
            new_cardinality.append((tuple(v for v,w in row['coefficients']),row['rhs']))
    coefficient,error,new,old,lr=V.renew(levels,vals+extensions+new_cardinality)
    expected=V.read(ROOT/'baseline/claim.json')
    need(V.fraction_pair(coefficient)==expected['exact_upper']and error==expected['finite_error'],
         'Endpoint changed; do not silently reuse publication metadata')
    pinned=V.read(ROOT/'baseline/VERIFIED_REPORT.json')
    need([r['table_sha256']for r in lr]==[r['table_sha256']for r in pinned['levels']],
         'Profiles differ from the claimed unchanged global result')
    result={'status':'COMPACT_PROFILE_REPLAYED_WITH_EXACT_BOUNDARY_EXTENSION',
            'baseline_files_hashed':hashed,'exact_upper':V.fraction_pair(coefficient),
            'decimal_upper':V.decimal(coefficient),'headline':expected['headline'],
            'finite_error':error,'finite':finite,'extensions':extstats,
            'new_cardinality_roots_checked':len(new_cardinality),
            'all_profile_hashes_unchanged':True,'new_global_bound_proved':False,
            'new_lean_compiled':False,'external_lean_rebuilt':False,
            'independent_human_review':False,'outside_packing_used':False,
            'boundary_statistics':{k:v for k,v in local.items()if k not in ('tables','proved_rows')},
            'external_input':{'repository':'KitaKen1/erdos-302-upper-bound','commit':V.PIN}}
    if args.report:args.report.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True))
if __name__=='__main__':main()
