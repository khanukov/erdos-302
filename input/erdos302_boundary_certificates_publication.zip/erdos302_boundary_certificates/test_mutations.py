#!/usr/bin/env python3
"""Fail-closed mutation regression tests for the new, local proof layer."""
from pathlib import Path
import copy
import importlib.util
import json

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('boundary_acceptance',ROOT/'verify_boundary.py')
checker=importlib.util.module_from_spec(spec);spec.loader.exec_module(checker)

def main():
    baseline=checker.read_json(ROOT/'certificate.json')
    checker.validate(baseline)
    tests=[]
    def add(name,change):tests.append((name,change))
    add('claimed stronger global bound',lambda d:d['baseline'].__setitem__('changes_global_bound',True))
    add('changed baseline fingerprint',lambda d:d['baseline'].__setitem__('claim_sha256','0'*64))
    add('overstated table minimum',lambda d:d['tables'][0]['cells'][1].__setitem__('lower',3))
    add('understated exact table minimum',lambda d:d['tables'][0]['cells'][1].__setitem__('lower',1))
    add('discard feasible state',lambda d:d['tables'][0]['cells'].__setitem__(1,{'lower':None,'witness':None}))
    add('invent feasible state',lambda d:d['tables'][0]['cells'].__setitem__(0,{'lower':0,'witness':0}))
    add('missing boundary state',lambda d:d['tables'][0]['cells'].pop())
    add('invalid cover witness',lambda d:d['tables'][0]['cells'][1].__setitem__('witness',0))
    add('out of range witness',lambda d:d['tables'][0]['cells'][1].__setitem__('witness',1<<12))
    add('incorrect boundary witness',lambda d:d['tables'][0]['cells'][1].__setitem__('witness',22))
    add('duplicate support vertex',lambda d:d['tables'][0]['support'].append(d['tables'][0]['support'][-1]))
    add('missing real edge',lambda d:d['tables'][0]['edges'].pop())
    add('invented arithmetic edge',lambda d:d['tables'][0]['edges'][0].__setitem__(0,9999))
    add('unconstrained boundary gate',lambda d:d['gates'][0].__setitem__('kind','free'))
    add('gate depends on external bit',lambda d:d['gates'][0].__setitem__('vertices',[4,12,999]))
    add('replace AND by one bit',lambda d:d['gates'][0].__setitem__('vertices',[4]))
    add('negative interior charge',lambda d:d['inequalities'][0].__setitem__('interior_coefficient',-1))
    add('boolean in place of integer',lambda d:d['inequalities'][0].__setitem__('interior_coefficient',True))
    add('overstated weighted demand',lambda d:d['inequalities'][0].__setitem__('rhs',6))
    add('invalid signed boundary coefficient',lambda d:d['inequalities'][0]['boundary_coefficients'].__setitem__(0,-1000))
    add('nonexistent table',lambda d:d['inequalities'][0].__setitem__('table','not-a-premise'))
    add('forward/circular derivation',lambda d:d['derived'][0]['parents'][0].__setitem__(0,'potential_cancelled'))
    add('negative combination weight',lambda d:d['derived'][0]['parents'][0].__setitem__(1,-1))
    add('hidden dropped vertex charge',lambda d:d['derived'][0]['coefficients'].pop())
    add('incorrect sum RHS',lambda d:d['derived'][0].__setitem__('rhs',4))
    add('uncancelled gate',lambda d:d['derived'][0].__setitem__('gate_terms',[['both_removed',1]]))
    add('too small rounding capacity',lambda d:d['derived'][1].__setitem__('capacity',1))
    add('wrong integer rounding',lambda d:d['derived'][1].__setitem__('rhs',4))
    add('invalid rank witness',lambda d:d['strict_relaxation_examples'][0].__setitem__('point',[[0,1]]*9))
    add('false separation objective',lambda d:d['strict_relaxation_examples'][0].__setitem__('expected_lhs',[4,1]))
    rejected=[]
    for name,mutate in tests:
        candidate=copy.deepcopy(baseline);mutate(candidate)
        try:checker.validate(candidate)
        except (ValueError,KeyError,TypeError,IndexError,ZeroDivisionError) as exc:
            rejected.append({'test':name,'rejected':True,'reason':str(exc)})
        else:raise RuntimeError('Invalid certificate accepted: '+name)
    print(json.dumps({'status':'ALL_MUTATIONS_REJECTED','valid_control_accepted':True,
                      'count':len(rejected),'tests':rejected},indent=2,sort_keys=True))
if __name__=='__main__':main()
