# Informative boundary certificates for Erdős Problem 302

Version: `boundary-certificates-v1` (2026-10-31). **Preliminary and unrefereed.**

This is a local certificate-language extension of the supplied compact package.
It does **not** announce a smaller global coefficient. The inherited result is

\[
\limsup_{N\to\infty} f_{302}(N)/N\le 0.841230807050.
\]

The exact coefficient and finite error remain the values in `baseline/claim.json`.
The new acceptance path checks exact boundary-state tables, derives signed
conditional inequalities and nonuniform weighted cover inequalities, and checks
explicit cancellation of boundary terms. Nine local inequalities strictly
strengthen the linear relaxation using **all subset-cardinality bounds on their
own support**. This does not mean the old integer proof system cannot derive them.

## What is included

- `certificate.json`: 12 exact tables / 84 boundary states, 12 weighted or
  conditional inequalities, and 11 further deductions.
- `verify_boundary.py`: standalone exact acceptance, including 4,352 subset-rank
  tests and explicit fractional separation witnesses.
- `crosscheck_boundary.py`: independent factorization-based edge generation,
  independent conditional-cost enumeration, and rank checks.
- `test_mutations.py`: 30 deliberately false/malformed inputs, all rejected.
- `verify_all.py`: replays the inherited finite proof bank and recurrence;
  inserts the 11 derived cardinal facts and checks that all 20 full profile
  hashes, the exact coefficient, and the error remain unchanged.
- `lean/BoundaryCertificates.lean`: 119 deterministic finite Lean declarations.
  **Generated, not compiled in this run.** This is not a new end-to-end Lean proof.
- `opb/`: nine independently reusable local weighted optimization instances,
  with exact optimal-cover witnesses. OPB files are not proof logs.
- `paper/BOUNDARY_CERTIFICATES_NOTE.md`: standalone mathematical appendix.
- `PUBLICATION_STATUS.md`: claims, dependencies, limits and review checklist.
- `baseline/`: the supplied compact result retained byte-for-byte, apart from
  omission of non-source Python cache files. Its mathematical external input is
  Kitamura's pinned smooth-profile theorem; that external Lean build is not rerun.

## Reproduce

Python 3.10+ is sufficient. Only the standard library is used for acceptance.
No network, solver, pickle, NumPy, SciPy or external packing is needed.

```bash
sha256sum -c SHA256SUMS
python3 -I -S -B -O verify_all.py --report replay.json
python3 -I -S -B -O crosscheck_boundary.py
python3 -I -S -B -O test_mutations.py
python3 -I -S -B -O generate_lean.py --check
```

For the new local layer alone:

```bash
python3 -I -S -B -O verify_boundary.py --report local.json
```

## Interpretation

The new data retain correlations discarded by a single statement
`tau(S) >= r`. This is preparation for boundary-aware optimization, not evidence
that the new correlations already improve the asymptotic coefficient. The
integrated regression explicitly reports `new_global_bound_proved: false`.

No repository branch, release, DOI, arXiv submission or journal status is changed
by this archive. No human review, new Lean compilation, or mathematical priority
claim is implied. The generic boundary/potential method is not claimed to be new
in the literature; these are certified problem-specific instances.
