#!/usr/bin/env python3
"""Adversarial regression tests; these supplement, not replace, the proof.
No fixture labels or expected numbers are used by the real acceptance checker.
"""
import copy,importlib.util,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('proofcheck',ROOT/'verify.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
levels=v.upstream();passed=[]
def small(S=(2,3,6),r=1):
 return {'schema':'erdos302-standalone-finite-proof-bank-v1','nodes':[{'t':'small','v':list(S),'r':r}],'images':[[0,1,1]],'roots':{'result':0}}
def reject(name,d):
 try:v.check_bank(d,levels)
 except (ValueError,TypeError,IndexError,KeyError,ZeroDivisionError):passed.append(name);return
 raise RuntimeError('accepted corrupt proof: '+name)
def change(d,f):
 d=copy.deepcopy(d);f(d);return d
b=small();v.check_bank(b,levels)
reject('false-small-demand',small(r=2))
reject('false-reciprocal-edge',small((2,3,5)))
reject('zero-denominator-vertex',small((0,2,3)))
reject('duplicate-vertex',small((2,2,3,6)))
reject('nonintegral-image',change(b,lambda d:d['images'].__setitem__(0,[0,1,2])))
reject('self-or-forward-image',change(b,lambda d:d['images'].__setitem__(0,[1,1,1])))
reject('negative-dilator',change(b,lambda d:d['images'].__setitem__(0,[0,-1,1])))
p=small();p['nodes'].append({'t':'pack','D':1,'rows':[[0,1]]});p['images'].append([1,1,1]);p['roots']={'result':1};v.check_bank(p,levels)
reject('overloaded-packing',change(p,lambda d:d['nodes'][1]['rows'].__setitem__(0,[0,2])))
reject('negative-weight',change(p,lambda d:d['nodes'][1]['rows'].__setitem__(0,[0,-1])))
reject('zero-capacity',change(p,lambda d:d['nodes'][1].__setitem__('D',0)))
reject('duplicate-packing-term',change(p,lambda d:d['nodes'][1]['rows'].append([0,1])))
q=small();q['nodes'].append({'t':'qpack','rows':[[0,1,1]]});q['images'].append([1,1,1]);q['roots']={'result':1};v.check_bank(q,levels)
reject('rational-zero-denominator',change(q,lambda d:d['nodes'][1]['rows'].__setitem__(0,[0,1,0])))
reject('rational-overload',change(q,lambda d:d['nodes'][1]['rows'].__setitem__(0,[0,3,2])))
c=small();c['nodes'].append({'t':'small','v':[3,4,12],'r':1})
c['images']=[[0,1,1],[1,1,1],[0,2,1],[2,1,1]]
c['nodes'].append({'t':'case','v':[2,3,4,6,12],'r':2,'cs':[0,1,2],
 'tree':[['dual',2,[[0,1],[1,1],[2,1]]]],'root':0});c['roots']={'result':3};v.check_bank(c,levels)
reject('false-dual-budget',change(c,lambda d:d['nodes'][2]['tree'].__setitem__(0,['dual',3,[[0,1],[1,1],[2,1]]])))
reject('fake-budget-leaf',change(c,lambda d:d['nodes'][2]['tree'].__setitem__(0,['budget'])))
reject('fake-row-leaf',change(c,lambda d:d['nodes'][2]['tree'].__setitem__(0,['row',0])))
reject('false-forcing',change(c,lambda d:(d['nodes'][2].__setitem__('tree',[['budget'],['force',0,0]]),d['nodes'][2].__setitem__('root',1))))
reject('missing-split-branch',change(c,lambda d:(d['nodes'][2].__setitem__('tree',[['dual',2,[[0,1],[1,1],[2,1]]],['split',2,0]]),d['nodes'][2].__setitem__('root',1))))
reject('cyclic-case-edge',change(c,lambda d:d['nodes'][2]['tree'].__setitem__(0,['split',2,0,0])))
# A formally plausible but false extension: no deletions outside {3}.
f={'source_node':0,'prime_level':0,'delete':[],'threshold':6,'required':1,'old':0,'outside':2,'outside_edges':1}
try:v.check_extensions([f],[((2,3,6),1)])
except ValueError:passed.append('uncovered-boundary-edge')
else:raise RuntimeError('accepted uncovered boundary edge')
# Correct zero-deletion extension for the full prime set.
f.update(prime_level=19,outside=0,outside_edges=0);v.check_extensions([f],[((2,3,6),1)])
f['required']=2
try:v.check_extensions([f],[((2,3,6),1)])
except ValueError:passed.append('inflated-extension-demand')
else:raise RuntimeError('accepted inflated extension demand')
f={'source_node':0,'prime_level':19,'delete':[],'threshold':5256,'required':1,'old':0,'outside':2,'outside_edges':0}
try:v.check_extensions([f],[((72,73,5256),1)])
except ValueError:passed.append('source-outside-enumerated-prime-universe')
else:raise RuntimeError('accepted incomplete edge universe')
print(json.dumps({'status':'ALL_NEGATIVE_TESTS_PASSED','rejected':len(passed),'tests':passed},indent=2))
