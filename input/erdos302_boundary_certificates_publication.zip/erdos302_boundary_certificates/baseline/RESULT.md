# Profile-only refinement for Erdős Problem 302

2026-10-31. Preliminary, unrefereed, computer-assisted.

## Scope

This package proves a stronger **profile-only** bound. It neither contains nor uses
any certificate of the previous 14,785,305-family outside packing. It must not be
advertised as improving the old combined bound below 0.84.

For every integer N >= 1,

    f(N) <= C N + 55,064,831,540.

Here

```
C = 5257732070693282578339807052385333596114146444258874863366093099862086223334703221767412397
    / 6250046986665851271465761945238620015244311869639997944823697072137494392402703576166400000
  = 0.841230807049991667993742190184877435609795058845356675464801...
```

Consequently

    limsup f(N)/N <= 841230807050 / 10^12 = 0.841230807050.

The headline is rounded **up**, verified with exact rational arithmetic.

## Comparison with the preceding compact profile

Previous exact coefficient:

    0.841263594505248412649144681704832083893277903867557856270635...

New exact coefficient:

    0.841230807049991667993742190184877435609795058845356675464801...

Exact decrease:

```
688945818799861731534463395438080869060608824433590272 / 21012482164444274161358942765379351631290286890125860117625
```

Decimal decrease: 0.0000327874552567446554024915199546482834828450222011808058336203.
Percentage-point decrease: 0.00327874552567446554024915199546482834828450222011808058336203.

This is a modest numerical improvement. No claim of optimality, a full solution,
an independently refereed result, or universal priority is made.

## Explicit dependencies

The input smooth-profile theorems of Kenta Kitamura at commit
`9447ceb28138949b2fb32442cec506a6f53104f9` remain external mathematical inputs.
Hashes fix transcriptions but do not prove the upstream theorems.
The upstream Lean development was not rebuilt, and this new layer was not
compiled in Lean in this run.
