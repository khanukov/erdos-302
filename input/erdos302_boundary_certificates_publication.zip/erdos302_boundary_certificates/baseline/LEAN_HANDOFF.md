# Lean handoff: profile-only bound 0.841230807050

This note is NOT a claim that the new data have been compiled in Lean.

## Target

Use the literal reciprocal-triple-free finite extremal function. Prove the
all-N inequality

    f302 N <= C*N + 55064831540

for the exact rational C in claim.json; then derive the eventual-epsilon/limsup
bound at 841230807050 / 10^12. Do not leave the all-N inequality as an unexplained
`hfinite` premise and advertise its conditional consequence as the final theorem.

## No new inference rule relative to the previous compact bank

The bank still uses small finite cover checks, positive rational dilation,
integer/rational weighted sums, Boolean splitting/forcing, isolated-vertex
removal and explicitly marked upstream active-prefix inputs. Extension covers
are checked against all actual boundary edges. The recurrence is the same
20-prime closure, now with stronger seeds and a pruned dependency DAG.

1. Prove the literal finite-cover checker soundness, with strictly earlier
   references. A rejected or missing proof may not be replaced by a hypothesis.
2. Check integer arithmetic and injective integral dilation.
3. Prove completeness of the arithmetic edge enumerator for extension covers.
4. Prove the parity-aware projection and explicit extension-cover lemma.
5. Prove the finite max recurrence by induction and its zero-correction extension.
6. Prove smooth/rough block disjointness, the prime recurrence reindexing and the
   finite inclusion-exclusion error used in PROOF.md.
7. Evaluate the certificate and rational sums in a proof-producing or kernel-only
   mode, and connect the result to the actual f302 definition.

Source pin: Kitamura repository, commit
9447ceb28138949b2fb32442cec506a6f53104f9. The four `externalActive` inputs and the
20 external profile inputs must be obtained from proof terms at that revision,
not from hashes or trusted JSON labels.

## Deliberately removed from the target

No outside packing, availability threshold, 14,785,305-family checker or combined
coefficient occurs here. Do not accidentally add the old outside gain to this
profile. No lower construction, density-limit assumption or analytic tail theorem
is an input either.

## Audit

Scan final sources for sorry/admit/axioms/unsafe escapes; inspect the exact
final theorem type and transitive `#print axioms`. A clean axiom report for a
conditional theorem does not establish its missing premise. Separately audit
completeness of the finite enumerator and exact correspondence to the intended
extremal problem. Run clean pinned builds and deliberate mutation tests.

Python's runtime is not a Lean runtime estimate. There are fewer total nodes and
weights than in the prior compact archive, but more case-tree nodes; no Lean
performance claim is made before an actual build.
