# Erdős 302: a compact profile-only refinement

Preliminary and unrefereed, 2026-10-31.

The result is

    limsup f(N)/N <= 0.841230807050,

and the exact finite inequality is in RESULT.md and claim.json.
This improves the preceding **profile-only** coefficient 0.841263594506.
It does not improve the stronger, different combined result 0.839541658150.

**There is no outside-packing dependency in this package.** No 14,785,305-family
payload, availability ledger, or C++ packing check is included or needed.

## Verification

Python 3 with its standard library only, on a platform with a 32-bit unsigned
`array('I')` (the checker tests this). No solver, NumPy/SciPy, network, C++ compiler,
or earlier research archive is needed to check the supplied new certificate.

```
sha256sum -c SHA256SUMS
python3 -I -S -B -O verify.py --report replay.json
python3 -I -S -B -O crosscheck.py --report replay.json
python3 -I -S -B -O test_verifier.py
```

The first program verifies the finite proof bank, boundary-extension witnesses,
renewal tables and exact coefficient. The second independently regenerates all
49,708 reciprocal edges and rebuilds all ten million recurrence entries solely
from the reported correction cells, comparing full table hashes. The third
rejects deliberately false finite proof objects. Tests supplement the mathematical
soundness argument; they do not prove it by themselves.

Verification has been run in normal and optimized modes; the resulting report
bytes agree. Logs are included. A fresh-archive replay was also performed.

## Trust boundary

The input is the pinned family of Kitamura smooth-profile theorems at commit
9447ceb28138949b2fb32442cec506a6f53104f9. Hashing the input transcription is NOT a
proof of those theorems. That upstream Lean project was not rebuilt in this run.

The new finite certificate is exactly checked by Python, and PROOF.md explains
its mathematical soundness and the all-N aggregation. The new proof layer has
NOT been compiled in Lean. No native result is mislabeled as a Lean kernel proof,
and no completed human peer review or priority claim is made.

## Files

- PROOF.md: full mathematical argument and the explicit external input.
- RESULT.md / claim.json: exact rational, headline and all-N additive error.
- bank.json.xz: forward-only finite proof DAG.
- extensions.json: explicit boundary-edge covers used in prime-set projection.
- upstream_intervals.json / upstream_thresholds.json: pinned theorem transcriptions.
- verify.py / crosscheck.py / test_verifier.py: accepting checks.
- VERIFIED_REPORT.json: full exact interval arithmetic and table hashes.
- SEARCH_REPORT.md: unsuccessful branches and limits of the search.
- LEAN_HANDOFF.md: what remains to be formalized.

The zip is a research artifact, not a GitHub release. The repository and published
release metadata were not changed.
