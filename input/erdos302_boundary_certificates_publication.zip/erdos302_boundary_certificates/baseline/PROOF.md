# A profile-only certificate refinement for Erdős Problem 302

Date: 2026-10-31. Preliminary and unrefereed.
This is a mathematical argument with exactly checked finite data, not a newly
completed end-to-end Lean formalization.

## 1. Statement and unchanged external input

For a finite set S of positive integers, let H(S) have edges the triples
{a,b,c} with a<b<c and bc=a(b+c), and let tau(S) be its vertex-cover number.
If f(N) is the largest triple-free subset of [1,N], then

    f(N) = N - tau([1,N]).

The claim is, for every N>=1,

    f(N) <= C*N + 55064831540,

where C is the exact rational in claim.json, independently recomputed by the
checker. In particular,

    limsup f(N)/N <= 0.841230807050.

We use the same pinned external smooth-prefix profile theorems as the preceding
package: Kenta Kitamura, `KitaKen1/erdos-302-upper-bound`, commit
`9447ceb28138949b2fb32442cec506a6f53104f9`, especially
`Erdos302ReflectiveChainFC.lean`, `Erdos302ReflectiveChainTopFC.lean`, and
`Erdos302ReflectiveChainData00FC.lean` through `Data19FC.lean`.
The present program rechecks the new finite deductions, the transcription's
aggregate, and all arithmetic. It does not rebuild that external Lean proof.

Let the prime order be

    3,2,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71.

Write P_j for the first j primes in this order, S_j(n) for the P_j-smooth
integers in [1,n], and L_j(n) for the externally proved lower cover profiles.
The pinned transcriptions reproduce Kitamura's exact aggregate coefficient.
They are premises with provenance, not mathematical conclusions of hashing.

## 2. The finite proof bank

Every bank node proves a literal statement tau(S)>=r. A node can refer only to
already verified nodes. Supports are normalized by their gcd; this is a positive
rational dilation, not an extra assumption. The new data use exactly the prior
rule types, with no new unproved pruning rule:

1. A support of at most nine vertices: enumerate its true reciprocal edges and
   reject every (r-1)-vertex cover, for r<=3. A smaller cover can be enlarged to
   size r-1, so this proves the desired lower bound.
2. Positive rational dilation whose images are all checked integral. Dilation
   preserves distinctness and the equation bc=a(b+c).
3. Integer or rational weighted addition of already proved cover constraints.
4. Exhaustive Boolean case trees with verified forcing and weighted leaf
   contradictions.
5. Removal of isolated vertices after complete edge enumeration.
6. Explicitly marked instances of the pinned upstream active-prefix theorem.

No claim is accepted merely because a numerical solver reports an optimum.

### Weighted rule

For configurations (S_i,r_i) with proved demands, weights w_i>=0 and capacity
D>0, check for every vertex v that sum_(i:v in S_i) w_i <= D. Every cover C then
satisfies

    sum_i w_i*r_i <= sum_i w_i*|C intersect S_i| <= D*|C|.

If the objective is strictly greater than D*(k-1), integrality gives |C|>=k.
The checker recomputes loads and the strict comparison exactly.

### Case-tree rule

For a target support T and proposed budget k-1, let O and Z be the selected and
excluded vertices at a search node, and F=T\(O union Z). A known (S,r) implies

    sum_(v in F intersect S) x_v
      >= r - |S\T| - |O intersect S|.

The justification is to extend a cover on S intersect T by S\T. An exact leaf
certificate is a nonnegative weighted sum of such residual constraints with
loads at most D and objective greater than D*(k-1-|O|). This contradicts the
remaining budget. Empty budget and impossible-row leaves are checked literally.
Forcing is permitted only when a residual demand equals the number of free
vertices in that row. A split must have both Boolean children. Induction over
the finite acyclic tree proves the root lower bound.

The additional successful case certificates include full smooth-prefix demands
at 720, 734, 900, 1000, 1500 and 1900. Failed stronger search targets are not
included as facts. Short triangle-type cover constraints also strengthen a
weighted certificate at 5000.

## 3. Projection to smaller prime sets

For Q a set of primes, let T be the Q-smooth part of a proved support S.
For any prime p, a reciprocal edge cannot have exactly one vertex divisible by p:
reduce bc=a(b+c) modulo p. Consequently an edge outside T has at least two
vertices outside T. Such an edge has at most one odd vertex, by the same identity
modulo 2. Thus every edge outside T has an EVEN vertex outside T.

It follows that

    tau(T) >= r - #{even vertices of S\T}.

There is a stronger finite witness rule. If U is an explicitly listed subset of
S\T meeting every edge of H(S) not contained in T, then

    tau(T) >= r-|U|.

Indeed, extending any cover of H(T) by U covers H(S). It is NOT necessary for U
to be a minimum cover. Only its size and the covering property are used.

The input extensions.json contains such witnesses. Every boundary edge is
checked against a complete finite enumeration. The main checker uses
(b-a)(c-a)=a^2; crosscheck.py independently regenerates edges with

    (a,b,c)=t*(uv,u(u+v),v(u+v)), u<v, gcd(u,v)=1.

For a prefix n, delete the Q-smooth vertices above n as well. This gives

    tau(T intersect [1,n]) >= r-|U|-|T intersect (n,infinity)|.

This supplies seed profiles without importing another optimization claim.

## 4. Consistent renewal closure

Take X=500000. Let s_j(n) be the strongest finite seed lower bound inferred by
the rules above, including the parity projection of all verified bank supports.
Set U_0=0 and U_j(0)=0, and process n in increasing order:

    U_j(n) = max(L_j(n), s_j(n), U_j(n-1),
                 U_(j-1)(n) + U_j(floor(n/p_j)))  (n<=X).

Each term is a valid lower bound. The last one follows from the vertex-disjoint
partition

    S_j(n) = S_(j-1)(n) disjoint-union p_j*S_j(floor(n/p_j)).

Cross-edges are not assumed absent. Ignoring them is safe for a lower bound on
the cover number. Induction in j and n therefore proves U_j(n)<=tau(S_j(n)).

Define

    d_j(n) = U_j(n)-U_(j-1)(n)-U_j(floor(n/p_j))  (n<=X),
    d_j(n) = 0                                  (n>X).

Extend all U_j to n>X by the same recurrence with zero correction. The resulting
functions remain valid lower bounds by strong induction. The new correction
is recomputed from scratch; old positive corrections are not blindly added to
new parent profiles. That would not be a justified inference.

All d_j are nonnegative and finitely supported. The checker gives them as
pairwise disjoint constant-height cells [a,b). Each full finite table also has a
canonical little-endian SHA-256 in VERIFIED_REPORT.json. The crosscheck rebuilds
all 10,000,000 table entries independently from the correction cells and compares
all twenty hashes, not merely selected values.

## 5. Global counting and the numerical bound

Let R_Q be the positive integers coprime to the product of primes in Q. Unique
smooth/rough factorization partitions [1,N] into the disjoint blocks

    q*S_20(floor(N/q)), q in R_(P_20), q<=N.

The complement of any triple-free set covers each block, so its cardinality is
at least the sum of the U_20 values over q. Iterating the renewal recurrence
rewrites this sum as

    sum_j sum_(q in R_(P_(j-1)), q<=N) d_j(floor(N/q)).

The exact reindexing at a level follows from unique writing of an integer
coprime to P_(j-1) as p_j^a*q with q coprime to P_j.
A correction cell [a,b) of height h contributes h times the number of q with

    N/b < q <= N/a, gcd(q,product(P_(j-1)))=1.

Finite inclusion-exclusion gives

    #q = rho_(j-1)*N*(1/a-1/b) + error,
    rho_(j-1)=product_(p in P_(j-1))(1-1/p),
    |error| <= 2^j.

Therefore, with

    G = sum_j rho_(j-1) * sum_cells h*(1/a-1/b),
    E = sum_j 2^j * sum_cells h,

we have for EVERY N>=1

    f(N) <= (1-G)*N+E.

The rational calculation gives 1-G=C from claim.json and E=55064831540.
The check C < 841230807050/10^12 is exact. Divide the finite inequality by N
and take limsup to conclude. No existence of a limiting density is assumed.

## 6. Compactness and scope

After discovery, retain only finite facts that actually improve a seed in the
renewal computation, and the proof ancestors needed to justify those facts.
Remove unused row references from case proofs. Replay the entire resulting
bank and extensions. Its final coefficient must exactly equal the unpruned
calculation; this was checked. Pruning is untrusted preprocessing.

This package contains NO outside packing, outside availability ledger, C++
packing checker, or claim derived by subtracting its density. It also contains
no analytical tail estimate, Ford theorem, or construction for #301/#327.
It is an improvement of 0.841263594506, not of the earlier combined number
0.839541658150.

The new data have not been compiled in Lean in this run. Human mathematical
review remains desirable; exact Python checking is not a claim of completed
formal verification.
