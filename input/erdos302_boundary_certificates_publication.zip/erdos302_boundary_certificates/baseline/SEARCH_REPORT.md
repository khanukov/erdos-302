# Search report and limitations

The source was the attached compact renewal artifact. It was checked from its
original hashes before exploration. Its profile-only result is
0.84126359450524841264914468170483208389327790386755785627063475654...

## Accepted changes

- Further explicit covers of edges leaving a smaller-prime part. Optimality of
  those covers is unnecessary: every listed cover was checked exactly.
- Exact case trees for six small/full smooth prefixes (720, 734, 900, 1000, 1500,
  1900). Proofs use weighted residual inequalities, two exhaustive children and
  justified forcing. New local requirements appear in the verified sample table.
- Short demand-two configurations from cycles of three reciprocal edges, followed
  by exact integer weighting. Numerical LP optima alone were never accepted.
- A new weighted proof at 5000 and small auxiliary proofs. Useful consequences
  were projected and propagated by the same consistent prime recurrence.
- Dependency pruning: only seed facts actually used by the max recurrence and
  their proof ancestors were retained. Unused case-row references were removed.
  The full coefficient was recomputed before and after pruning and agreed exactly.

## Searches that did NOT enter the final claim

- A finite lattice of alternative small-prime pivots produced an additional
  exploratory micro-gain, but would add a more complicated checking layer. It is
  not used in this result. The final proof has the original fixed prime order.
- Extending the recurrence range to two million gave only a tiny exploratory
  tail improvement. The final cutoff remains 500000.
- Discarding the upstream profile family weakened the result. The external input
  is not silently dropped.
- Full-prefix goals176 at 1200,261 at 1900,296 at 2200 and327 at 2500 were not certified
  within the search budget. A second attempt at175 at 1200 and293 at 2200 also did
  not finish. They are not mathematical bounds in this package.
- The weaker target260 at 1900 did obtain a complete finite certificate.
- An LP attempt at 10000 with many cycle constraints hit its time limit without
  a usable solution. It contributed no accepted result.
- Numerical probing of unrestricted [1,N] was not confused with a single smooth
  fiber: the former contains additional rough-multiplier fibers. Its values were
  not inserted as smooth-fiber bounds.

Candidate generation used SciPy/HiGHS and floating-point arithmetic. Every accepted
lower bound was converted into finite integer/rational proof data and replayed
by the separate standard-library checker. Upper witnesses for boundary deletion
were verified as covers; solver claims of their optimality were not used.

## Measurements

See VERIFIED_REPORT.json and logs/. Normal and optimized reports agree exactly.
All 49,708 edges were independently regenerated, and all 10,000,000 recurrence
entries were reconstructed and compared by canonical per-table hashes.
22 mutation classes were rejected.

The result is a modest numerical improvement, not a breakthrough towards 0.83.
Pruning reduced the final data, but the additional branching made this run's
Python verification somewhat slower than the previous compact baseline.
No current literature sweep, upstream Lean rebuild, new Lean compilation,
external human review or repository write was performed.
