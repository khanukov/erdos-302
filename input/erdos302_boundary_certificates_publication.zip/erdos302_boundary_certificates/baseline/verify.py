#!/usr/bin/env python3
"""Independent standard-library verifier for a consolidated proof bank and renewal bound.
No search, numerical LP, previous archive imports, pickle, or assert on the accepting path.
The pinned smooth-profile theorem of Kitamura is an explicit external input;
this program checks the new finite mathematics, not that external Lean build.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, lzma, math, sys, time
from array import array
from fractions import Fraction
from pathlib import Path
from decimal import Decimal, localcontext
ROOT=Path(__file__).resolve().parent
P=(3,2,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71)
P_SORT=tuple(sorted(P))
PIN='9447ceb28138949b2fb32442cec506a6f53104f9'
INTERVALS_SHA='b9f1b518c895fffc8efe40b6abb9b39cd877ef77ef0c78b5211b5b103b117111'
THRESHOLDS_SHA='39495c149fcad3c56209115023c5fdb907628cde1fd36fd279e95b3fbeae099b'
CK=Fraction(303298432907684665348375061155255053723893276661771828230864577892179469,358435072543067896655954874015956559321978063343228205466655134412800000)
def require(x,msg):
 if not x:raise ValueError(msg)
def integer(x,lo=None,hi=None):return type(x)is int and (lo is None or x>=lo)and(hi is None or x<=hi)
def read(p):
 def hook(pairs):
  d={}
  for k,v in pairs:require(k not in d,'duplicate JSON field');d[k]=v
  return d
 p=Path(p)
 if p.suffix=='.xz':
  with lzma.open(p,'rt',encoding='utf-8')as f:text=f.read(64000001)
  require(len(text)<=64000000,'expanded JSON exceeds size limit')
 else:text=p.read_text()
 return json.loads(text,object_pairs_hook=hook)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def fraction_pair(q):return [q.numerator,q.denominator]
def decimal(q):
 with localcontext()as c:c.prec=65;return str(Decimal(q.numerator)/Decimal(q.denominator))
def smooth(n):
 for p in P:
  while n%p==0:n//=p
 return n==1

def table_hash(a):
 require(a.itemsize==4,'profile table requires 32-bit unsigned array storage')
 b=array('I',a)
 if sys.byteorder!='little':b.byteswap()
 return hashlib.sha256(b.tobytes()).hexdigest()

def upstream():
 require(digest(ROOT/'upstream_intervals.json')==INTERVALS_SHA,'changed upstream intervals')
 require(digest(ROOT/'upstream_thresholds.json')==THRESHOLDS_SHA,'changed upstream crosscheck')
 d=read(ROOT/'upstream_intervals.json');require(d['commit']==PIN and d['pivots']==list(P[::-1]),'upstream source pin')
 levels=d['intervals'][::-1];require(len(levels)==len(P),'upstream levels')
 gain=Fraction();rho=Fraction(1)
 for p,rows in zip(P,levels):
  for a,b in rows:require(integer(a,1,500001)and integer(b,a,500001),'invalid upstream interval')
  gain+=rho*sum((Fraction(1,a)-Fraction(1,b)for a,b in rows),Fraction());rho*=Fraction(p-1,p)
 require(1-gain==CK,'upstream aggregate mismatch')
 return levels

def old_profiles(levels,X):
 parent=array('I',[0])*(X+1)
 for p,rows in zip(P,levels):
  diff=array('i',[0])*(X+2)
  for a,b in rows:
   if a<=X:diff[a]+=1
   if b<=X:diff[b]-=1
  out=array('I',[0])*(X+1);c=0
  for n in range(1,X+1):c+=diff[n];out[n]=parent[n]+out[n//p]+c
  parent=out
 return parent

def edges(S):
 ss=set(S);out=[]
 for b,c in itertools.combinations(S,2):
  a,r=divmod(b*c,b+c)
  if r==0 and a in ss:out.append((a,b,c))
 return out

def normalize(S):
 S=tuple(sorted(set(S)));require(S and all(integer(v,1)for v in S),'empty/nonpositive support')
 g=math.gcd(*S);return tuple(v//g for v in S)

def check_bank(data,levels):
 require(set(data)=={'schema','nodes','images','roots'},'bank fields')
 require(data['schema']=='erdos302-standalone-finite-proof-bank-v1','bank schema')
 nodes=data['nodes'];images=data['images'];roots=data['roots']
 require(type(nodes)is list and nodes and type(images)is list and type(roots)is dict,'bank arrays')
 extmax=max([1]+[n['n']for n in nodes if n.get('t')=='externalActive']);require(extmax<=500000,'external query range')
 old=old_profiles(levels,extmax)
 results=[];memo={};stats={'small':0,'small_subset_tests':0,'pack':0,'qpack':0,'case':0,'case_nodes':0,'case_weight_entries':0,'weight_entries':0,'externalActive':0,'trim':0}
 def image(j,upto):
  require(integer(j,0,len(images)-1),'image index')
  ref=images[j];require(type(ref)is list and len(ref)==3,'image shape');i,m,d=ref
  require(integer(i,0,upto-1)and integer(m,1)and integer(d,1)and math.gcd(m,d)==1,'forward image or invalid scale')
  if j not in memo:
   S,k=results[i];require(all(v*m%d==0 for v in S),'noninteger dilation');memo[j]=(tuple(v*m//d for v in S),k)
  return memo[j]
 for idx,node in enumerate(nodes):
  require(type(node)is dict and 't'in node,'node syntax');typ=node['t']
  if typ=='small':
   require(set(node)=={'t','v','r'},'small fields');S=node['v'];k=node['r']
   require(type(S)is list and 3<=len(S)<=9 and all(integer(v,1)for v in S)and S==sorted(set(S)),'small support')
   require(integer(k,1,3),'small demand');ee=edges(S);require(ee,'no genuine reciprocal edge')
   for C in itertools.combinations(S,k-1):
    stats['small_subset_tests']+=1;cc=set(C);require(any(cc.isdisjoint(e)for e in ee),'false small demand')
  elif typ in ('pack','qpack'):
   require(set(node)==({'t','D','rows'}if typ=='pack'else{'t','rows'}),'pack fields')
   cap=node['D']if typ=='pack'else Fraction(1);require((typ=='qpack')or integer(cap,1),'capacity')
   loads={};obj=0;seen=set()
   require(type(node['rows'])is list and node['rows'],'empty packing')
   for row in node['rows']:
    require(type(row)is list and len(row)==(2 if typ=='pack'else 3),'weight shape')
    j=row[0];require(j not in seen,'duplicate image in packing');seen.add(j)
    require(all(integer(w,1)for w in row[1:]),'nonpositive weight')
    w=row[1]if typ=='pack'else Fraction(row[1],row[2]);T,r=image(j,idx);obj+=w*r
    for v in T:loads[v]=loads.get(v,0)+w
    stats['weight_entries']+=1
   require(loads and max(loads.values())<=cap,'overloaded vertex')
   ratio=Fraction(obj)/cap;k=(ratio.numerator+ratio.denominator-1)//ratio.denominator;S=tuple(sorted(loads))
   require(k>=1 and obj>cap*(k-1),'invalid rounded objective')
  elif typ=='trim':
   require(set(node)=={'t','ref'},'trim fields');T,k=image(node['ref'],idx)
   require(len(T)<=2000,'trim support resource limit');S=sorted({v for e in edges(T)for v in e});require(S,'trim removed every vertex')
  elif typ=='externalActive':
   require(set(node)=={'t','n'}and integer(node['n'],1,extmax),'external fields')
   n=node['n'];T=[v for v in range(1,n+1)if smooth(v)];k=old[n];S=sorted({v for e in edges(T)for v in e})
   require(k>0,'zero external demand')
  elif typ=='case':
   require(set(node)=={'t','v','r','cs','tree','root'},'case fields')
   S=node['v'];k=node['r'];require(type(S)is list and S==sorted(set(S))and all(integer(v,1)for v in S),'case support')
   require(integer(k,1,len(S))and type(node['cs'])is list,'case demand')
   T=frozenset(S);cs=[]
   for j in node['cs']:
    U,r=image(j,idx);U=frozenset(U);cs.append((U&T,r-len(U-T)))
   tree=node['tree'];require(type(tree)is list and tree and node['root']==len(tree)-1,'case root')
   visited=set()
   def walk(j,ones,zeros,depth):
    require(integer(j,0,len(tree)-1)and depth<=len(T),'invalid tree/depth');visited.add(j);stats['case_nodes']+=1
    z=tree[j];require(type(z)is list and z,'tree node');kind=z[0];free=T-ones-zeros;budget=k-1-len(ones)
    def con(i):require(integer(i,0,len(cs)-1),'case constraint');return cs[i]
    if kind=='budget':require(len(z)==1 and budget<0,'false budget contradiction')
    elif kind=='row':
     require(len(z)==2,'row fields');U,r=con(z[1]);require(r-len(U&ones)>len(U&free),'false row contradiction')
    elif kind=='force':
     require(len(z)==3 and integer(z[2],0,j-1),'force child');U,r=con(z[1]);forced=U&free
     require(r-len(U&ones)==len(forced)>0,'unjustified force');walk(z[2],ones|forced,zeros,depth+len(forced))
    elif kind=='split':
     require(len(z)==4 and z[1]in free and integer(z[2],0,j-1)and integer(z[3],0,j-1),'invalid split')
     walk(z[2],ones,zeros|{z[1]},depth+1);walk(z[3],ones|{z[1]},zeros,depth+1)
    elif kind=='dual':
     require(len(z)==3 and integer(z[1],1)and type(z[2])is list,'dual fields');D=z[1];loads={};obj=0;seen=set()
     for pair in z[2]:
      require(type(pair)is list and len(pair)==2,'dual weight pair');i,w=pair;require(integer(w,1)and i not in seen,'dual weight');seen.add(i)
      U,r=con(i);res=r-len(U&ones);require(res>0,'nonpositive residual');obj+=res*w;stats['case_weight_entries']+=1
      for v in U&free:loads[v]=loads.get(v,0)+w
     require(max(loads.values(),default=0)<=D and obj>D*budget,'false dual contradiction')
    else:raise ValueError('unknown case node')
   walk(node['root'],frozenset(),frozenset(),0);require(visited==set(range(len(tree))),'unreachable case data')
  else:raise ValueError('unknown finite proof rule')
  stats[typ]+=1;S=normalize(S);require(integer(k,1,len(S)),'invalid proven demand');results.append((S,k))
 assertions=[]
 for name,j in roots.items():
  require(type(name)is str,'root label');S,k=image(j,len(nodes));assertions.append((S,k))
 stats['nodes']=len(nodes);stats['images']=len(images);stats['named_roots']=len(assertions)
 # All internally verified nodes are also usable assertions; normalization is
 # a positive rational dilation, whose integrality is literal.
 return results,assertions,stats

def rank_table(M):
 rem=list(range(M+1));rank=[-1]*(M+1)
 for i,p in enumerate(P):
  for n in range(p,M+1,p):
   while rem[n]>1 and rem[n]%p==0:rem[n]//=p
   rank[n]=max(rank[n],i)
 for n in range(1,M+1):
  if rem[n]!=1:rank[n]=100
 return rank

def check_extensions(rows,results):
 require(type(rows)is list,'extension list')
 if not rows:return [],{'count':0,'deleted_vertices':0}
 M=max(results[row['source_node']][0][-1]for row in rows)
 ranks=rank_table(M);smooths={n for n in range(1,M+1)if ranks[n]<=19}
 # Complete independent enumeration via (b-a)(c-a)=a^2.
 all_edges=[]
 for a in sorted(smooths):
  if 2*a>=M:break
  z=a;ds=[1]
  for p in P_SORT:
   exp=0
   while z%p==0:exp+=1;z//=p
   if exp:
    prev=ds;ds=[];q=1
    for j in range(2*exp+1):ds.extend(d*q for d in prev);q*=p
  require(z==1,'factorization failed')
  for d in ds:
   if d>=a:continue
   b=a+d;c=a+a*a//d
   if c<=M and b in smooths and c in smooths:all_edges.append((a,b,c))
 cache={};out=[];deleted=0;seen=set()
 for row in rows:
  require(set(row)=={'source_node','prime_level','delete','threshold','required','old','outside','outside_edges'},'extension fields')
  i,lev=row['source_node'],row['prime_level'];require(integer(i,0,len(results)-1)and integer(lev,0,19),'extension origin')
  require((i,lev)not in seen,'duplicate extension');seen.add((i,lev))
  S,k=results[i];ss=set(S);require(ss<=smooths,'extension source outside enumerated smooth universe');T=tuple(v for v in S if ranks[v]<=lev);tt=set(T);U=row['delete']
  require(type(U)is list and U==sorted(set(U))and all(integer(v,1)for v in U),'extension deletion syntax')
  uu=set(U);require(uu<=ss-tt,'extension deletion not outside target')
  if i not in cache:cache[i]=[e for e in all_edges if all(v in ss for v in e)]
  for e in cache[i]:require(all(v in tt for v in e)or any(v in uu for v in e),'uncovered boundary edge')
  r=k-len(uu);require(r>0 and r<=len(T)and row['required']==r and row['threshold']==S[-1],'extension result mismatch')
  require(row['outside']==len(ss-tt),'outside count mismatch')
  er={tuple(v for v in e if v not in tt)for e in cache[i]if any(v not in tt for v in e)}
  require(row['outside_edges']==len(er),'outside edge count mismatch')
  out.append((T,r));deleted+=len(uu)
 return out,{'count':len(out),'deleted_vertices':deleted,'full_arithmetic_edges':len(all_edges),'source_supports':len(cache),'edge_universe_max':M,'edge_list_sha256':hashlib.sha256(json.dumps(sorted(all_edges),separators=(',',':')).encode()).hexdigest()}

def renew(levels,witnesses,X=500000):
 require(X==500000,'the published upstream recurrence cut-off is 500000')
 M=max(S[-1]for S,k in witnesses);require(M<=X,'witness outside recursion table');rank=rank_table(M)
 oldparent=array('I',[0])*(X+1);newparent=array('I',[0])*(X+1);rho=Fraction(1);gain=Fraction();error=0;level_reports=[]
 for lev,(p,intervals)in enumerate(zip(P,levels)):
  seed=array('I',[0])*(X+1)
  for S,k in witnesses:
   allowed=[v for v in S if rank[v]<=lev]
   # Prime-support projection: each reciprocal triple has either zero or
   # at least two non-Q-smooth vertices, and at most one odd vertex.
   # Deleting only the EVEN non-Q-smooth vertices therefore covers every
   # edge not fully contained in allowed.
   cost=sum(1 for v in S if rank[v]>lev and v%2==0)
   d=k-cost-len(allowed)
   require(d<=0,'projection contradicts empty-cover bound')
   for v in allowed:
    d+=1
    if d>seed[v]:seed[v]=d
  diff=array('i',[0])*(X+2)
  for a,b in intervals:
   if a<=X:diff[a]+=1
   if b<=X:diff[b]-=1
  old=array('I',[0])*(X+1);new=array('I',[0])*(X+1);iv=0;last=0;start=1;J=Fraction();height_sum=0;cells=[]
  for n in range(1,X+1):
   iv+=diff[n];require(iv>=0,'negative original correction');old[n]=oldparent[n]+old[n//p]+iv
   rec=newparent[n]+new[n//p];v=max(rec,new[n-1],old[n],seed[n]);new[n]=v;c=v-rec
   if c!=last:
    if last:
     J+=last*(Fraction(1,start)-Fraction(1,n));height_sum+=last;cells.append([start,n,last])
    start=n;last=c
  if last:J+=last*(Fraction(1,start)-Fraction(1,X+1));height_sum+=last;cells.append([start,X+1,last])
  gain+=rho*J;error+=(2**(lev+1))*height_sum
  level_reports.append({'prime':p,'correction_cells':len(cells),'height_sum':height_sum,'rho':fraction_pair(rho),'J':fraction_pair(J),'cells':cells,'table_sha256':table_hash(new)})
  rho*=Fraction(p-1,p);oldparent,newparent=old,new
 # Independently re-check the pinned prefix transcription against the rebuilt old table.
 thresholds=read(ROOT/'upstream_thresholds.json');require(len(thresholds)==768,'threshold count')
 for i,(n,k)in enumerate(thresholds):
  require(oldparent[n]==k,'old threshold mismatch')
  if i+1<len(thresholds):require(oldparent[thresholds[i+1][0]-1]==k,'old plateau mismatch')
 return 1-gain,error,newparent,oldparent,level_reports


BASELINE=Fraction(152480172821047102664249187166731782766270375304565340192010470673834999199143732485701961113,181251362613309686872507096411919980442085044219559940399887215091987337379678403708825600000)
HEADLINE=Fraction(841230807050,10**12)

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--bank',type=Path,default=ROOT/'bank.json.xz');ap.add_argument('--report',type=Path);args=ap.parse_args()
 st=time.time();levels=upstream();data=read(args.bank);vals,roots,stats=check_bank(data,levels)
 ext,estats=check_extensions(read(ROOT/'extensions.json'),vals)
 bound,E,new,old,lr=renew(levels,vals+ext)
 require(bound<HEADLINE,'announced headline is not proved')
 require(bound<BASELINE,'no improvement over preceding profile-only bound')
 claim=read(ROOT/'claim.json')
 require(fraction_pair(bound)==claim['exact_upper'] and E==claim['finite_error'],'claimed exact result differs from recomputation')
 require(claim['headline']==[841230807050,10**12],'wrong scope or endpoint')
 report={'status':'EXACT_PROFILE_ONLY_REFINEMENT_VERIFIED','finite':stats,'extensions':estats,
  'exact_upper':fraction_pair(bound),'decimal_upper':decimal(bound),'headline':[841230807050,10**12],
  'finite_error':E,'baseline':fraction_pair(BASELINE),'exact_improvement':fraction_pair(BASELINE-bound),
  'decimal_improvement':decimal(BASELINE-bound),'levels':lr,
  'samples':[[n,int(old[n]),int(new[n])]for n in (500,600,720,734,900,1000,1200,1500,1900,5000,10000,40000,100000,500000)],
  'outside_packing_used':False,'external_input':{'repository':'KitaKen1/erdos-302-upper-bound','commit':PIN,'lean_rebuilt':False},
  'new_lean_compiled':False,'human_review':False}
 if args.report:args.report.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k!='levels'},indent=2,sort_keys=True))
 print('Elapsed seconds: '+str(round(time.time()-st,3)),file=sys.stderr)
if __name__=='__main__':main()
