#!/usr/bin/env python3
"""Independent primitive-parameter edge enumeration and exact ledger arithmetic.
This does not establish the external pinned Lean theorem or run the large packing.
"""
import argparse,hashlib,importlib.util,json,math
from fractions import Fraction as F
from pathlib import Path
ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('pc',ROOT/'verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--report',type=Path,default=ROOT/'VERIFIED_REPORT.json');args=ap.parse_args();r=v.read(args.report)
 M=r['extensions']['edge_universe_max'];rank=v.rank_table(M);E=set()
 for b in range(2,math.isqrt(M)+1):
  for a in range(1,b):
   if math.gcd(a,b)!=1 or rank[a]>19 or rank[b]>19 or rank[a+b]>19:continue
   A,B,C=a*b,a*(a+b),b*(a+b)
   for t in range(1,M//C+1):
    if rank[t]<=19:E.add((t*A,t*B,t*C))
 for a,b,c in E:
  v.require(a<b<c and b*c==a*(b+c),'invalid primitive image')
  v.require((a%2)+(b%2)+(c%2)<=1,'parity counterexample')
  rs=[rank[a],rank[b],rank[c]];v.require(rs.count(max(rs))>=2,'prime projection counterexample')
 eh=hashlib.sha256(json.dumps(sorted(E),separators=(',',':')).encode()).hexdigest()
 v.require(len(E)==r['extensions']['full_arithmetic_edges']and eh==r['extensions']['edge_list_sha256'],'independent edge enumeration differs')
 # Rebuild each renewal function solely from correction records, without
 # witnesses, maxima, restrictions, or original upstream profile tables.
 from array import array
 X=500000;parent=array('I',[0])*(X+1);gain=F();rho=F(1);err=0;cellcount=0
 for j,l in enumerate(r['levels']):
  p=l['prime'];v.require(p==v.P[j]and F(*l['rho'])==rho,'renewal order')
  events={};end=0;J=F();hs=0
  for a,b,h in l['cells']:
   v.require(1<=a<b<=X+1 and a>=end and h>0,'correction cell ordering');end=b
   events[a]=events.get(a,0)+h;events[b]=events.get(b,0)-h
   J+=h*(F(1,a)-F(1,b));hs+=h;cellcount+=1
  v.require(J==F(*l['J'])and hs==l['height_sum'],'correction integral')
  out=array('I',[0])*(X+1);c=0
  for n in range(1,X+1):
   c+=events.get(n,0);v.require(c>=0,'negative reconstructed correction');out[n]=parent[n]+out[n//p]+c
  v.require(v.table_hash(out)==l['table_sha256'],'independent table reconstruction differs')
  parent=out;gain+=rho*J;rho*=F(p-1,p);err+=2**(j+1)*hs
 v.require(1-gain==F(*r['exact_upper'])and err==r['finite_error'],'profile arithmetic')
 for n,old,new in r['samples']:v.require(parent[n]==new,'renewal sample')
 v.require(1-gain<F(*r['headline']),'outward rounding')
 print(json.dumps({'status':'INDEPENDENT_PROFILE_ONLY_CROSSCHECK_PASSED','reciprocal_edges':len(E),'edge_sha256':eh,'prime_projection_and_parity_checks':len(E),'reconstructed_and_hash_compared_entries':20*X,'correction_cells':cellcount,'profile_decimal':v.decimal(1-gain),'outside_packing_used':False},indent=2))
if __name__=='__main__':main()
