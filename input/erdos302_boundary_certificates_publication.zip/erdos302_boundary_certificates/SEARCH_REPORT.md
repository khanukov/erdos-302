# Actual discovery and negative findings in this run

Inputs: supplied erdos302_profile_0841230807050.zip and
 erdos302_compact_research_20261031.zip. No new literature search or live GitHub
update was performed; contemporary research claims from earlier conversation
messages are not silently incorporated as dependencies.

The compact baseline was replayed. Candidate nonuniform inequalities were found
by separation of local cover polytopes using SciPy linprog. Numerical output was
not an acceptance criterion. Supports had at most nine vertices; all final
coefficient vectors are integral, use only 1 and 2, and were verified over every
Boolean cover. The nine rows and exact state tables are in certificate.json.

At the 1000-prefix diagnostic, the ordinary-cardinality LP was 151 within
floating-point precision. Adding the first nine discovered local weighted cuts
did not raise that objective in the completed tested iterations. The scan for
further cuts was bounded; no claim of complete separation/closure is made.

The exact experiment with the existing global checker appended the eleven
cardinal consequences of the new rows to the verified bank. Its coefficient,
finite error and all twenty full-profile hashes remained exactly unchanged.
No smaller global constant was obtained. This finding is not hidden behind the
strict local polyhedral improvements.

The best new claim is therefore structural and verifiable: locally, the new
language proves inequalities not implied by the linear relaxation of all subset
rank/cardinality bounds. All nine separating fractional witnesses are rational
and are checked against every subset, including the empty and full subsets.

An attempted retrieval of a Lean binary could not resolve the external host.
There was no installed Lean toolchain, so compilation has not been performed.
Generated Lean source is provided without a compilation-success claim. This
technical limitation says nothing about the mathematical statements' difficulty.
