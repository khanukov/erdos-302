#!/usr/bin/env python3
"""Exact boundary summaries and weighted cover inequalities for Erdos #302.

Acceptance is standard-library only. Complete tables on at most ten vertices
are checked exhaustively. No optimizer, floats, native-evaluation axiom or
claim about a new global numerical bound is used by this program.
"""
from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import itertools
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent
MAX_VERTICES = 10
MAX_BOUNDARY = 4


def require(condition: bool, message: str) -> None:
    if not condition:
        raise ValueError(message)


def integer(value: Any, low: int | None = None) -> bool:
    return type(value) is int and (low is None or value >= low)


def read_json(path: Path) -> Any:
    def unique(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result = {}
        for key, value in pairs:
            require(key not in result, f"Duplicate field: {key}")
            result[key] = value
        return result
    require(path.stat().st_size <= 5_000_000, "Input exceeds resource limit")
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique)


def vertex_list(value: Any, name: str) -> list[int]:
    require(type(value) is list, f"{name}: not a list")
    require(all(integer(v, 1) for v in value), f"{name}: invalid vertex")
    require(value == sorted(set(value)), f"{name}: not strictly increasing")
    return value


def reciprocal_edges(vertices: list[int]) -> list[list[int]]:
    allowed = set(vertices)
    result = []
    for b, c in itertools.combinations(vertices, 2):
        a, rem = divmod(b * c, b + c)
        if rem == 0 and a in allowed:
            result.append([a, b, c])
    return result


def semantic_covers(vertices: list[int], edges: list[list[int]]) -> list[int]:
    index = {v: i for i, v in enumerate(vertices)}
    masks = [sum(1 << index[v] for v in edge) for edge in edges]
    return [mask for mask in range(1 << len(vertices))
            if all(mask & edge for edge in masks)]


def signed_terms(value: Any, variable_kind: str) -> dict[Any, int]:
    require(type(value) is list, "Terms must be a list")
    result = {}
    for pair in value:
        require(type(pair) is list and len(pair) == 2, "Invalid term")
        key, coefficient = pair
        require((integer(key, 1) if variable_kind == "vertex" else type(key) is str),
                "Invalid term variable")
        require(key not in result and integer(coefficient) and coefficient != 0,
                "Duplicate, zero or noninteger coefficient")
        result[key] = coefficient
    return result


def clean(coefficients: dict[Any, int]) -> dict[Any, int]:
    return {key: value for key, value in coefficients.items() if value != 0}


def validate(cert: dict[str, Any]) -> dict[str, Any]:
    require(type(cert) is dict and set(cert) == {
        "schema", "baseline", "gates", "tables", "inequalities", "derived",
        "strict_relaxation_examples"}, "Invalid root fields")
    require(cert["schema"] == "erdos302-boundary-weighted-v1", "Wrong schema")
    baseline = cert["baseline"]
    require(set(baseline) == {"archive_name", "archive_sha256", "claim_sha256",
                             "headline", "changes_global_bound"}, "Baseline fields")
    require(baseline["changes_global_bound"] is False, "A global improvement is not proved here")
    require(baseline["headline"] == [841230807050, 10**12], "Wrong baseline endpoint")
    require(hashlib.sha256((ROOT / "baseline/claim.json").read_bytes()).hexdigest()
            == baseline["claim_sha256"], "Baseline claim fingerprint mismatch")
    gates: dict[str, list[int]] = {}
    for gate in cert["gates"]:
        require(set(gate) == {"id", "kind", "vertices"}, "Gate fields")
        name = gate["id"]
        require(type(name) is str and name not in gates, "Invalid gate ID")
        require(gate["kind"] == "and", "Unsupported gate")
        members = vertex_list(gate["vertices"], "AND gate")
        require(1 <= len(members) <= MAX_BOUNDARY, "Gate arity")
        gates[name] = members

    tables: dict[str, Any] = {}
    total_assignments = 0
    total_cells = 0
    table_report = []
    for table in cert["tables"]:
        require(set(table) == {"id", "support", "boundary", "edges", "cells"}, "Table fields")
        tid = table["id"]
        require(type(tid) is str and tid not in tables, "Invalid/duplicate table ID")
        support = vertex_list(table["support"], "support")
        boundary = vertex_list(table["boundary"], "boundary")
        require(1 <= len(support) <= MAX_VERTICES, "Support exceeds exhaustive limit")
        require(len(boundary) <= MAX_BOUNDARY and set(boundary) <= set(support), "Invalid boundary")
        actual_edges = reciprocal_edges(support)
        require(table["edges"] == actual_edges, "Arithmetic edge list is not exact")
        cells = table["cells"]
        require(type(cells) is list and len(cells) == 1 << len(boundary), "Missing/extra boundary state")
        loc = {v: i for i, v in enumerate(support)}
        inside = [v for v in support if v not in boundary]
        inside_mask = sum(1 << loc[v] for v in inside)
        covers = semantic_covers(support, actual_edges)
        observed: list[int | None] = [None] * len(cells)
        for mask in covers:
            state = sum(((mask >> loc[v]) & 1) << i for i, v in enumerate(boundary))
            cost = (mask & inside_mask).bit_count()
            if observed[state] is None or cost < observed[state]:
                observed[state] = cost
        for state, cell in enumerate(cells):
            require(type(cell) is dict and set(cell) == {"lower", "witness"}, "Cell fields")
            lower, witness = cell["lower"], cell["witness"]
            require(lower is None or integer(lower, 0), "Cell cost is not natural/null")
            require(lower == observed[state], "Incorrect exact boundary cost/infeasibility")
            if lower is None:
                require(witness is None, "Witness for infeasible state")
            else:
                require(integer(witness, 0) and witness < 1 << len(support), "Witness range")
                require(witness in covers, "Witness does not cover")
                require(all(((witness >> loc[v]) & 1) == ((state >> i) & 1)
                            for i, v in enumerate(boundary)), "Witness boundary mismatch")
                require((witness & inside_mask).bit_count() == lower, "Witness has wrong cost")
        tables[tid] = {"support": support, "boundary": boundary, "interior": inside,
                       "costs": observed, "covers": covers}
        total_assignments += 1 << len(support)
        total_cells += len(cells)
        table_report.append({"id": tid, "support": support, "boundary": boundary,
                             "minimum_interior_costs": observed,
                             "minimum_total_cover": min(mask.bit_count() for mask in covers)})

    proved: dict[str, Any] = {}
    for row in cert["inequalities"]:
        require(set(row) == {"id", "table", "interior_coefficient",
                             "boundary_coefficients", "gate_terms", "rhs"}, "Inequality fields")
        name, tid = row["id"], row["table"]
        require(type(name) is str and name not in proved and tid in tables, "Inequality ID/premise")
        table = tables[tid]
        a, beta, rhs = row["interior_coefficient"], row["boundary_coefficients"], row["rhs"]
        require(integer(a, 0), "Negative/noninteger interior coefficient is unsound for a lower summary")
        require(type(beta) is list and len(beta) == len(table["boundary"])
                and all(integer(c) for c in beta) and integer(rhs), "Boundary coefficients/RHS")
        gt = signed_terms(row["gate_terms"], "gate")
        require(all(key in gates and set(gates[key]) <= set(table["boundary"]) for key in gt),
                "Gate is not fully defined on the boundary")
        for state, cost in enumerate(table["costs"]):
            if cost is None:
                continue  # Infeasibility was exhaustively proved above, not assumed.
            bits = {v: (state >> j) & 1 for j, v in enumerate(table["boundary"])}
            value = a * cost + sum(c * bits[v] for c, v in zip(beta, table["boundary"]))
            value += sum(c * int(all(bits[v] for v in gates[key])) for key, c in gt.items())
            require(value >= rhs, "Boundary summary does not imply proposed inequality")
        coefficients = {v: a for v in table["interior"]}
        coefficients.update(zip(table["boundary"], beta))
        proved[name] = {"coefficients": clean(coefficients), "gates": gt, "rhs": rhs,
                        "support": table["support"], "origin_table": tid}

    for row in cert["derived"]:
        require(type(row) is dict and "kind" in row, "Derived node")
        name = row.get("id")
        require(type(name) is str and name not in proved, "Duplicate derived ID")
        if row["kind"] == "sum":
            require(set(row) == {"id", "kind", "parents", "coefficients", "gate_terms", "rhs"}, "Sum fields")
            coefficients, gt, rhs = {}, {}, 0
            seen = set()
            require(type(row["parents"]) is list and row["parents"], "Empty sum")
            for pair in row["parents"]:
                require(type(pair) is list and len(pair) == 2, "Sum parent shape")
                ref, weight = pair
                require(ref in proved and ref not in seen and integer(weight, 1), "Forward/circular parent or invalid weight")
                seen.add(ref)
                premise = proved[ref]
                rhs += weight * premise["rhs"]
                for v, c in premise["coefficients"].items():
                    coefficients[v] = coefficients.get(v, 0) + weight * c
                for key, c in premise["gates"].items():
                    gt[key] = gt.get(key, 0) + weight * c
            coefficients, gt = clean(coefficients), clean(gt)
            require(coefficients == signed_terms(row["coefficients"], "vertex") and
                    gt == signed_terms(row["gate_terms"], "gate") and integer(row["rhs"]) and rhs == row["rhs"],
                    "Incorrect sum or hidden double charge")
        elif row["kind"] == "cover_rounding":
            require(set(row) == {"id", "kind", "parent", "capacity", "support", "rhs"}, "Round fields")
            ref, cap = row["parent"], row["capacity"]
            require(ref in proved and integer(cap, 1), "Rounding premise/capacity")
            source = proved[ref]
            support = vertex_list(row["support"], "rounding support")
            require(not source["gates"] and set(source["coefficients"]) <= set(support), "Uncancelled gate or missing vertex")
            require(all(0 <= c <= cap for c in source["coefficients"].values()), "Capacity cannot absorb coefficient")
            rhs = -(-source["rhs"] // cap)
            require(integer(row["rhs"]) and rhs == row["rhs"], "Incorrect integer rounding")
            coefficients, gt = {v: 1 for v in support}, {}
        else:
            raise ValueError("Unknown derivation rule")
        proved[name] = {"coefficients": coefficients, "gates": gt, "rhs": rhs,
                        "support": sorted(coefficients), "origin_table": None}

    strict_report = []
    subset_constraints_checked = 0
    for row in cert["strict_relaxation_examples"]:
        require(set(row) == {"inequality", "point", "expected_lhs"}, "Separation fields")
        name = row["inequality"]
        require(name in proved and not proved[name]["gates"], "Separation refers to invalid inequality")
        proof = proved[name]
        require(proof["origin_table"] in tables, "Separation requires a local table")
        table = tables[proof["origin_table"]]
        support, covers = table["support"], table["covers"]
        require(type(row["point"]) is list and len(row["point"]) == len(support), "Fractional point dimension")
        values = []
        for pair in row["point"]:
            require(type(pair) is list and len(pair) == 2 and integer(pair[0]) and integer(pair[1], 1), "Fraction syntax")
            value = Fraction(*pair)
            require(0 <= value <= 1, "Fractional point outside cube")
            values.append(value)
        for subset in range(1 << len(support)):
            # This is exactly tau(H[subset]): extend a cover by the complement.
            demand = min((mask & subset).bit_count() for mask in covers)
            lhs = sum((values[j] for j in range(len(support)) if (subset >> j) & 1), Fraction())
            require(lhs >= demand, "Point violates an ordinary subset-cardinality constraint")
            subset_constraints_checked += 1
        lhs = sum((proof["coefficients"].get(v, 0) * x for v, x in zip(support, values)), Fraction())
        require(type(row["expected_lhs"]) is list and len(row["expected_lhs"]) == 2
                and all(integer(q) for q in row["expected_lhs"]) and row["expected_lhs"][1] > 0,
                "Separation objective syntax")
        require(lhs == Fraction(*row["expected_lhs"]) and lhs < proof["rhs"], "Not a strict relaxation separation")
        strict_report.append({"inequality": name, "lhs": [lhs.numerator, lhs.denominator],
                              "required": proof["rhs"], "all_subset_bounds_checked": 1 << len(support)})

    # Every emitted inequality is also checked directly on all covers of its union
    # support. This is a redundant, separate check of the symbolic table/sum bridge.
    total_direct = 0
    for name, proof in proved.items():
        support = sorted(set(proof["support"]) | {v for key in proof["gates"] for v in gates[key]})
        require(len(support) <= MAX_VERTICES, "Direct regression check exceeds size bound")
        for mask in semantic_covers(support, reciprocal_edges(support)):
            bits = {v: (mask >> i) & 1 for i, v in enumerate(support)}
            lhs = sum(c * bits[v] for v, c in proof["coefficients"].items())
            lhs += sum(c * int(all(bits[v] for v in gates[key])) for key, c in proof["gates"].items())
            require(lhs >= proof["rhs"], f"Direct soundness regression failed: {name}")
            total_direct += 1

    exported = [{"id": name, "coefficients": sorted(p["coefficients"].items()),
                 "gate_terms": sorted(p["gates"].items()), "rhs": p["rhs"]}
                for name, p in proved.items()]
    return {"status": "BOUNDARY_TABLES_AND_WEIGHTED_CUTS_EXACTLY_VERIFIED",
            "baseline_headline": baseline["headline"], "new_global_bound_proved": False,
            "outside_packing_used": False, "new_lean_compiled": False,
            "table_count": len(tables), "boundary_states": total_cells,
            "exhaustive_table_assignments": total_assignments,
            "weighted_and_conditional_inequalities": len(cert["inequalities"]),
            "derived_inequalities": len(cert["derived"]), "direct_cover_checks": total_direct,
            "strict_separations": strict_report, "all_subset_constraints_checked": subset_constraints_checked,
            "tables": table_report, "proved_rows": exported,
            "interpretation": "Strictly stronger LOCAL linear relaxation, not a claim of a lower global density bound or an impossibility theorem for integer branching."}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--certificate", type=Path, default=ROOT / "certificate.json")
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    report = validate(read_json(args.certificate))
    text = json.dumps(report, indent=2, sort_keys=True) + "\n"
    if args.report:
        args.report.write_text(text, encoding="utf-8")
    print(text, end="")


if __name__ == "__main__":
    main()
