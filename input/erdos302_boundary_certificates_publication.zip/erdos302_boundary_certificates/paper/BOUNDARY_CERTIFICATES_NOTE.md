# Boundary summaries and weighted cover inequalities for reciprocal-triple hypergraphs

**Draft mathematical appendix — 2026-10-31. Preliminary and unrefereed.**

## 1. Scope

For a finite set S of positive integers, let H(S) have an edge {a,b,c} whenever
its members can be ordered as a<b<c and bc=a(b+c). A cover C meets every edge.
Write x_v=1 if v is in C, and x_v=0 otherwise. The extremal function in #302 is
f(N)=N-tau(H([1,N])).

This note adds a finite, informative certificate interface to the supplied
profile-only proof. It proves local inequalities and their checking rules.
It does not establish a new value below the inherited global endpoint
0.841230807050. No result of #301 or #327 and no large outside packing is used.

## 2. Exact boundary summaries

Partition a finite support S as B disjoint-union I. For a Boolean state
sigma:B->{0,1}, define

    kappa(sigma) = min |C intersect I|,

where C ranges over covers of H(S) with C intersect B prescribed by sigma.
Set kappa(sigma)=infinity if this class is empty.

The certificate stores one entry for EVERY boundary state, including impossible
states. Each finite entry has both an exhaustive lower-bound check and a cover
witness achieving the stated value. Thus these tables are exact, not just
solver-reported lower estimates. In this artifact |S|<=9 and |B|<=3; the checker
allows |S|<=10, |B|<=4. Those limits are resource guards, not mathematical
assumptions on arbitrary instances.

Let a>=0 be an integer, let beta_b be signed integers, and let z_j(sigma) be
explicitly defined Boolean functions of boundary variables. If

    a*kappa(sigma) + sum_b beta_b*sigma_b + sum_j gamma_j*z_j(sigma) >= r

for every feasible state, then every cover satisfies

    a*sum_(v in I) x_v + sum_(b in B) beta_b*x_b + sum_j gamma_j*z_j(x) >= r.

Proof: condition on its actual boundary state and use
|C intersect I|>=kappa(sigma). Nonnegativity of a is essential. An impossible
state may be omitted only AFTER its impossibility has been proved. In the
implementation z_j is an explicit conjunction, not an unconstrained variable.

## 3. A short weighted inequality on eight denominators

Let

    I = {12,15,20,28,60},  B = {21,30,70},  S = I union B.

Its true reciprocal edges are

    {12,15,60}, {12,20,30}, {15,20,60}, {12,21,28},
    {20,28,70}, {20,30,60}, {21,30,70}.

For every cover C of this hypergraph,

    2*|C intersect I| + |C intersect B| >= 5.                  (3.1)

Proof. The last edge forces at least one element of B. The first and third
edges force at least one element of I. If there are at least two selected
vertices in I, (3.1) follows. If exactly one is selected, it must lie in
{12,15,60} intersect {15,20,60}={15,60}. Then the edges
{12,20,30}, {12,21,28}, {20,28,70} force all three elements of B.
Again the cost is at least 5.

The exact boundary table has kappa=2 when one or two boundary vertices are
selected, kappa=1 when all three are selected, and the empty state is impossible.
Every finite entry is accompanied by an explicit attaining cover.

### Why the information is strictly stronger than subset ranks

On S in the displayed sorted order, take the rational point

    x=(1/2,1/2,1/2,1/2,0,1/2,0,1/2).

The checker verifies, for ALL 256 subsets U of S,

    sum_(v in U) x_v >= tau(H(U)).

Nevertheless the left-hand side of (3.1) is 9/2<5. Thus (3.1) is not implied
by the linear relaxation consisting of the cube and all subset-cardinality
constraints on S. This is a local polyhedral separation statement. It does
not assert that (3.1) cannot be deduced by integer case splitting, or that it
improves the global density bound when inserted alone.

The artifact supplies nine such inequalities. Eight separate their local rank
relaxation at 9/2<5; the remaining one separates it at 7/2<4. All rational
separations are checked exactly, not accepted from a numerical LP tolerance.

For clarity, tau(H(U)) can be computed equivalently by

    min_(C cover of H(S)) |C intersect U|.

One direction follows by restriction. The other follows by extending a cover
of H(U) by every vertex in S\U. The independent checker instead enumerates
covers of H(U) directly.

## 4. A reusable parametric family

For any integer p>=4, put

    a=2(p-1), b=2p, c=2(p+1),
    d=2p(p-1), e=2p^2, f=2p(p+1),
    g=p(p^2-1), h=2p^2(p-1), i=2p^2(p+1).

These nine positive integers are distinct. The following six triples are true
reciprocal edges:

    {a,b,d}, {b,c,f}, {d,e,h}, {d,f,g}, {e,f,i}, {g,h,i}.

All identities follow by substituting the formulas into yz=x(y+z); equivalently
the differences of consecutive reciprocals telescope. For p>=4 the six interior
vertices a,...,f precede g<h<i, since g/f=(p-1)/2>1.

For any cover of these six edges, let r be its number of vertices in
I={a,b,c,d,e,f}, and s its number in B={g,h,i}. Then

    2r+s >= 5.                                               (4.1)

Proof. The boundary edge gives s>=1. The first two edges imply r>=1. If r=1,
the only possible interior vertex meeting both is b. The three middle edges
then force g,h,i, so s=3. If r>=2, s>=1 suffices.

This proves a weighted inequality simultaneously for all p>=4 and all positive
rational dilations with integral images. It uses only the six specified edges;
extra reciprocal edges cannot invalidate it. Exact table values for the FULL
induced hypergraph at every p are not asserted. The p=4 table is checked exactly,
and p=4,...,200 are additional finite arithmetic regression tests, not a proof
of the universal statement. No historical novelty of this familiar type of
local configuration is claimed.

## 5. Shared-state potentials and safe cancellation

Let A={2,3,4,6,12}, J={5,20,30}, and z=x_4*x_12. The true edges

    {2,3,6}, {3,4,12}, {4,6,12}, {4,5,20}, {12,20,30}

imply

    sum_(v in A) x_v >= 2+z,
    sum_(v in J) x_v >= 1-z.

For the first inequality the three internal edges need two deletions; selecting
both 4 and 12 forces one more in {2,3,6}. For the second, if either 4 or 12 is
not selected, its crossing edge forces a selection in J. If both are selected,
the lower bound is zero. Adding cancels z and proves three deletions.

The charged sets A and J are disjoint. The second summary reads the boundary
{4,12} but charges those boundary vertices with coefficient zero. The checker
adds the actual coefficient dictionaries and checks every coefficient and gate
term, rather than assuming that overlapping subproblems can be summed.

For a general family of inequalities, nonnegative integer linear combinations
are valid. Auxiliary variables may be eliminated only by exact coefficient
cancellation, or by another proved rule. A cardinal conclusion can be extracted
from a nonnegative weighted row sum a_v*x_v>=r with a_v<=D by

    D*sum_v x_v >= r, so sum_v x_v >= ceil(r/D).

The denominator/capacity must be positive. The checker also rejects duplicate or
forward premise references and unaccounted vertex charges.

## 6. Relation to the inherited global theorem

The previous compact proof and its fixed Kitamura input are retained in
baseline/. Running verify_all.py proves the same finite estimate from that
source chain,

    f(N) <= C*N + 55064831540,

with the exact C in baseline/claim.json and C<0.841230807050. The 11 ordinary
cardinal conclusions of the new local language can be inserted into its renewal
calculation: all twenty table hashes, the coefficient and the finite error remain
UNCHANGED. This is an explicit negative numerical finding, not a failure to run
the calculation.

Obtaining a smaller coefficient requires a downstream optimization that uses
the nonuniform coefficients or boundary conditions themselves. Merely replacing
each new statement by its total-cardinality consequence loses the extra
information, as the replay demonstrates. No new global value is claimed in
this appendix, and no subtraction of a local improvement from C is permitted.

## 7. Trust, provenance, and computational disclosure

The accepting code uses only Python's standard library and exact integers or
Fractions. Discovery used numerical linear optimization to propose weighted
rows. Final inequalities, table minima, witnesses, and separation points are
rechecked by complete finite computation. A second implementation uses a
different edge-generation identity and directly solves induced-subset covers.
Thirty deliberately corrupted certificate variants are rejected.

The global statement still imports Kitamura's smooth-profile theorem at commit
9447ceb28138949b2fb32442cec506a6f53104f9, as documented in baseline/PROOF.md.
No external Lean rebuild was performed here. The generated Lean file contains
119 finite declarations, but has not been compiled in this run. It is not a
formal proof of the global endpoint. Independent human review is pending.

The general principles of boundary conditioning, weighted inequalities and
potential cancellation are not claimed as new methods. This note records
checked instances for reciprocal hypergraphs. AI assisted the discovery,
implementation, proofs and drafting; the human author's review and acceptance
of responsibility must not be asserted until they have actually occurred.
