# Publication status and claim ledger

Date: 2026-10-31. Draft artifact, not a new release or submission.

## Safe statements supported by the artifact

1. The supplied compact proof reproduces the exact coefficient in
   baseline/claim.json, rounded upward as 0.841230807050, with finite error
   55064831540, subject to its explicitly pinned external mathematical input.
2. Twelve exact boundary tables are independently checked; all 84 states include
   either a proved minimum and attaining witness or proved infeasibility.
3. Nine certified weighted inequalities strictly strengthen the local continuous
   relaxation with every subset-cardinality constraint. Explicit rational
   separating points certify the strictness. Integer reasoning is not ruled out.
4. Potential cancellation is checked on the real eight-denominator example.
5. A uniform family of six real reciprocal edges gives 2|C intersect I|+|C
   intersect B|>=5 by the elementary proof in the appendix.
6. Inserting the eleven cardinal consequences into the existing renewal code
   leaves all twenty profiles and the global coefficient unchanged.

## Statements NOT established here

- A new numerical bound below 0.841230807050.
- A complete solution of #302, optimality of the baseline, or a world-record claim.
- An improvement over the older combined result using the excluded outside
  packing. These are different methods and should not be compared as if identical.
- A complete Lean verification of the global baseline or new boundary framework.
- Independent human peer review or author signoff.
- A benchmark claim that Lean is faster: no Lean compilation was run.

## Publication files

The appendix is paper/BOUNDARY_CERTIFICATES_NOTE.md. It separates the inherited
global theorem from newly proved local lemmas and the experimentally unchanged
coefficient. The full provenance of the inherited coefficient stays in baseline/.
Do not relabel this append-only artifact as a numerical improvement.

## Before a public mathematical announcement

- [x] Readable statement, proof of every new rule, local witnesses and exact data.
- [x] Independent finite cross-check and negative/mutation tests.
- [x] Explicit external theorem pin and no outside packing.
- [x] Reproduction commands and normal/optimized-mode agreement.
- [ ] Review the conditional semantics and rank-separation claim by a human.
- [ ] Compile the generated Lean source and inspect all axiom reports.
- [ ] Integrate the semantic bridge to the literal #302 definition.
- [ ] Obtain the human author's actual review/attribution/license approval.
- [ ] Confirm live literature before claiming mathematical novelty or priority.
- [ ] Create a versioned release/DOI only after the owner chooses the release scope.

A preliminary unrefereed artifact can be shared for review before every formal
item is complete, with the limits above explicit. No claim of peer review should
be made. The manuscript does not assert that a human has already reviewed it.
