# Lean integration handoff — informative local certificates

## Implemented versus not implemented

The mathematical local checker is executable and tested in Python. The finite
Lean source is generated deterministically. **No Lean compiler was available in
this run, and the generated file has not been compiled.** Do not change its
status to checked merely because Python accepted the same statement.

Target the repository's existing pinned Lean/Mathlib toolchain; do not silently
upgrade dependencies. The baseline bundle uses the pinned profile input described
in its proof. No global theorem should be replaced by a conditional placeholder.

## First integration job

1. Run all exact Python checks.
2. Run `python3 -I -S -B -O generate_lean.py --check`.
3. Copy `lean/BoundaryCertificates.lean` into a compatible Lake project.
4. Run `lake env lean BoundaryCertificates.lean` and collect all 119 axiom reports.
5. Reject `sorryAx`, custom axioms, native-evaluation axioms and unaccounted
   assumptions. Expected standard axioms are at most `propext`,
   `Classical.choice`, `Quot.sound`; finite declarations may use fewer.

The file has finite arithmetic edge statements, all 84 conditional lower-bound
or infeasibility statements, and all 23 emitted inequalities/cardinal consequences.
It has no `sorry`, `admit`, `native_decide`, unsafe override or new axiom. That
source property is NOT a substitute for compilation and axiom inspection.

## Reusable theorems to formalize next

Use a finite indexed support, its embedding into positive natural denominators,
and a deletion bit for each index. Establish:

- Every triple-free subset induces deletion bits satisfying every checked real
  reciprocal edge. Injectivity and positivity of the embedding are required.
- `boundaryTable_sound`: every cover with boundary state sigma has interior
  charge at least the verified table value. `none` means proved infeasibility,
  not an absent row. All states must be covered.
- `boundaryWeighted_sound`: multiply interior lower bounds only by nonnegative
  coefficients; boundary coefficients and gate coefficients may be signed.
- Auxiliary AND gates are definitions/total Boolean functions. They are not new
  assumptions that may restrict the original covers.
- `linearCombination_sound`: exact addition with nonnegative integer weights.
- `cardinalityOfBoundedWeights`: gate-free nonnegative coefficients bounded by
  D>0 give the ceiling cardinal lower bound.
- One independent semantic bridge from arithmetic edge lists to the actual
  problem definition. A theorem about an arbitrary Boolean formula is not yet
  a theorem about Erdős #302.

## Size and integration strategy

The new tables have at most 9 vertices and 3 boundary bits in the supplied data.
A kernel-only check is realistic at this size, but its runtime is not measured
here. The existing global proof bank and renewal chain are unchanged. The new
11 ordinary cardinal roots reproduce exactly the previous global profiles.
To improve the global constant, preserve the richer rows in search; do not
throw them away at the interface by reducing everything immediately to tau(S).

## Acceptance requirements

- All finite outputs agree with the Python and independent enumeration.
- The exact global coefficient remains unchanged unless a NEW global certificate
  is supplied and replayed. No informal subtraction of local savings.
- Source/axiom scans include transitive dependencies, not only this generated file.
- Draft/manuscript metadata separates the exact external verifier, finite Lean
  checks, and the unfinished complete formalization of the strengthened language.
