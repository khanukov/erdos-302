#!/usr/bin/env python3
"""Second implementation: factorization edges and subset enumeration.
Does not import the accepting checker or use its edge/cost routines.
"""
from pathlib import Path
from fractions import Fraction
import itertools
import json
import math

ROOT = Path(__file__).resolve().parent

def need(ok, message):
    if not ok:
        raise RuntimeError(message)

def edges_by_factors(S):
    ss = set(S)
    E = set()
    for a in S:
        for d in range(1, a):
            if a*a % d:
                continue
            b, c = a+d, a+a*a//d
            if b in ss and c in ss:
                E.add((a,b,c))
    return E

def tau(S, edges):
    for k in range(len(S)+1):
        for C in itertools.combinations(S,k):
            chosen=set(C)
            if all(chosen.intersection(e) for e in edges):
                return k
    raise RuntimeError('Finite hypergraph must have a cover')

def main():
    data=json.loads((ROOT/'certificate.json').read_text())
    tables={}
    checked_states=0
    for t in data['tables']:
        S=t['support'];B=t['boundary'];I=[v for v in S if v not in B]
        E=edges_by_factors(S)
        need(E==set(map(tuple,t['edges'])),'Independent edge mismatch')
        for state,cell in enumerate(t['cells']):
            fixed={v for j,v in enumerate(B) if state//(2**j)%2}
            obtained=None
            for k in range(len(I)+1):
                if any(all((fixed|set(C)).intersection(e) for e in E)
                       for C in itertools.combinations(I,k)):
                    obtained=k
                    break
            need(obtained==cell['lower'],'Independent boundary minimum mismatch')
            checked_states+=1
        tables[t['id']]=(S,B,I,E)
    inequalities={r['id']:r for r in data['inequalities']}
    tested=0
    for s in data['strict_relaxation_examples']:
        r=inequalities[s['inequality']];S,B,I,E=tables[r['table']]
        x={v:Fraction(*q) for v,q in zip(S,s['point'])}
        for k in range(len(S)+1):
            for U in itertools.combinations(S,k):
                us=set(U);induced=[e for e in E if set(e)<=us]
                need(sum(x[v]for v in U)>=tau(U,induced),'Independent subset rank mismatch')
                tested+=1
        lhs=r['interior_coefficient']*sum(x[v]for v in I)+sum(c*x[v]for v,c in zip(B,r['boundary_coefficients']))
        need(not r['gate_terms'] and lhs<r['rhs'],'No strict separation')
    # Parametric nine-vertex family: a finite regression test, not its proof for all p.
    family_tests=0
    for p in range(4,201):
        I=[2*(p-1),2*p,2*(p+1),2*p*(p-1),2*p*p,2*p*(p+1)]
        B=[p*(p*p-1),2*p*p*(p-1),2*p*p*(p+1)]
        a,b,c,d,e,f=I;g,h,i=B
        E=[(a,b,d),(b,c,f),(d,e,h),(d,f,g),(e,f,i),(g,h,i)]
        need(len(set(I+B))==9,'Family vertices not distinct')
        for x,y,z in E:
            x,y,z=sorted((x,y,z))
            need(y*z==x*(y+z),'Family reciprocal identity')
        family_tests+=1
    report={'status':'INDEPENDENT_BOUNDARY_AND_RANK_CROSSCHECK_PASSED',
            'tables':len(tables),'boundary_states':checked_states,
            'subset_rank_constraints':tested,'finite_parametric_instances':family_tests,
            'new_global_bound_proved':False,'lean_compiled':False}
    print(json.dumps(report,indent=2,sort_keys=True))
if __name__=='__main__':main()
